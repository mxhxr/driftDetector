# =============================================================
#  audit_checks.py  –  Individual CIS compliance audit checks
# =============================================================
from __future__ import annotations

import logging
import uuid

import pyodbc

from db_manager import AuditResult, list_user_databases

logger = logging.getLogger(__name__)

# Extended stored procs that PUBLIC should NOT have EXECUTE on
XP_PROCEDURES: list[str] = [
    "xp_availablemedia",
    "xp_dirtree",
    "xp_enumgroups",
    "xp_fixeddrives",
    "xp_servicecontrol",
    "xp_subdirs",
    "xp_regaddmultistring",
    "xp_regdeletekey",
    "xp_regdeletevalue",
    "xp_regenumvalues",
    "xp_regremovemultistring",
    "xp_regwrite",
    "xp_regread",
]


# ── Helper ─────────────────────────────────────────────────────────────────

def _make_result(
    run_id: uuid.UUID,
    server: str,
    category: str,
    item: str,
    current: str | None,
    target: str | None,
    status: str,
    database: str | None = None,
    error: str | None = None,
) -> AuditResult:
    return AuditResult(
        run_id=run_id,
        server_name=server,
        database_name=database,
        check_category=category,
        check_item=item,
        current_value=current,
        target_value=target,
        status=status,
        error_message=error,
    )


# ── Check 1: Server Configurations ────────────────────────────────────────

# Maps config-name → (target_value, comparison_operator)
SERVER_CONFIG_TARGETS: dict[str, tuple[str, str]] = {
    "scan for startup procs": ("0",  "EQUALS"),
    "SQL Mail XPs":           ("0",  "EQUALS"),
    "max number of error logs": ("12", "GTE"),
}


def check_server_configs(
    conn: pyodbc.Connection,
    server: str,
    run_id: uuid.UUID,
) -> list[AuditResult]:
    """
    CIS checks against sys.configurations.
    Targets: scan for startup procs=0, SQL Mail XPs=0,
             max number of error logs>=12.
    """
    results: list[AuditResult] = []

    sql = """
        SELECT name, CAST(value_in_use AS BIGINT) AS value_in_use
        FROM   sys.configurations
        WHERE  name IN ({placeholders})
    """.format(placeholders=",".join("?" * len(SERVER_CONFIG_TARGETS)))

    try:
        cursor = conn.cursor()
        cursor.execute(sql, list(SERVER_CONFIG_TARGETS.keys()))
        rows = {row.name: row.value_in_use for row in cursor.fetchall()}

        for cfg_name, (target_str, operator) in SERVER_CONFIG_TARGETS.items():
            current_val = rows.get(cfg_name)
            if current_val is None:
                results.append(_make_result(
                    run_id, server, "ServerConfig", cfg_name,
                    current="NOT_FOUND", target=target_str, status="SKIPPED",
                    error=f"Config '{cfg_name}' not returned by sys.configurations",
                ))
                continue

            current_str = str(current_val)
            target_int   = int(target_str)

            if operator == "EQUALS":
                passed = int(current_val) == target_int
            elif operator == "GTE":
                passed = int(current_val) >= target_int
            else:
                passed = current_str == target_str

            status = "PASS" if passed else "DRIFT"
            results.append(_make_result(
                run_id, server, "ServerConfig", cfg_name,
                current=current_str, target=target_str, status=status,
            ))
            logger.debug("[%s] ServerConfig '%s': current=%s, target=%s(%s) → %s",
                         server, cfg_name, current_str, operator, target_str, status)

    except pyodbc.Error as exc:
        logger.error("[%s] check_server_configs failed: %s", server, exc)
        for cfg_name in SERVER_CONFIG_TARGETS:
            results.append(_make_result(
                run_id, server, "ServerConfig", cfg_name,
                current=None, target=None, status="ERROR", error=str(exc),
            ))

    return results


# ── Check 2: XP Procedure PUBLIC Permissions ──────────────────────────────

def check_xp_permissions(
    conn: pyodbc.Connection,
    server: str,
    run_id: uuid.UUID,
) -> list[AuditResult]:
    """
    Detects if PUBLIC has EXECUTE granted on any of the dangerous
    extended stored procedures in master.
    Drift = permission IS granted (should be revoked).
    """
    results: list[AuditResult] = []

    sql = """
        SELECT o.name AS proc_name
        FROM   master.sys.database_permissions dp
        JOIN   master.sys.database_principals  pr
               ON dp.grantee_principal_id = pr.principal_id
        JOIN   master.sys.objects o
               ON dp.major_id = o.object_id
        WHERE  pr.name            = 'public'
          AND  dp.permission_name = 'EXECUTE'
          AND  dp.state           IN ('G', 'W')
          AND  o.name             IN ({placeholders})
    """.format(placeholders=",".join("?" * len(XP_PROCEDURES)))

    try:
        cursor = conn.cursor()
        cursor.execute(sql, XP_PROCEDURES)
        granted_set = {row.proc_name for row in cursor.fetchall()}

        for proc in XP_PROCEDURES:
            if proc in granted_set:
                # PUBLIC has EXECUTE → DRIFT
                results.append(_make_result(
                    run_id, server, "XPPermission", proc,
                    current="GRANTED", target="REVOKED", status="DRIFT",
                ))
            else:
                results.append(_make_result(
                    run_id, server, "XPPermission", proc,
                    current="REVOKED", target="REVOKED", status="PASS",
                ))
            logger.debug("[%s] XPPermission '%s': %s",
                         server, proc, "DRIFT" if proc in granted_set else "PASS")

    except pyodbc.Error as exc:
        logger.error("[%s] check_xp_permissions failed: %s", server, exc)
        for proc in XP_PROCEDURES:
            results.append(_make_result(
                run_id, server, "XPPermission", proc,
                current=None, target="REVOKED", status="ERROR", error=str(exc),
            ))

    return results


# ── Check 3: Guest CONNECT Permissions ────────────────────────────────────

def check_guest_connect(
    conn: pyodbc.Connection,
    server: str,
    run_id: uuid.UUID,
) -> list[AuditResult]:
    """
    Checks each user database for 'guest' having CONNECT permission.
    Excludes system databases (master, msdb, tempdb) per CIS guidance.
    """
    results: list[AuditResult] = []
    databases = list_user_databases(conn)

    if not databases:
        logger.debug("[%s] No user databases found for guest-connect check.", server)

    for db_name in databases:
        sql = """
            SELECT dp.state_desc
            FROM   [{db}].sys.database_permissions dp
            JOIN   [{db}].sys.database_principals  pr
                   ON dp.grantee_principal_id = pr.principal_id
            WHERE  pr.name            = 'guest'
              AND  dp.permission_name = 'CONNECT'
              AND  dp.state           IN ('G', 'W')
        """.replace("{db}", db_name)

        try:
            cursor = conn.cursor()
            cursor.execute(sql)
            row = cursor.fetchone()
            if row:
                status    = "DRIFT"
                current   = "CONNECT_GRANTED"
            else:
                status    = "PASS"
                current   = "NO_CONNECT"

            results.append(_make_result(
                run_id, server, "GuestConnect", "guest_connect",
                current=current, target="NO_CONNECT", status=status,
                database=db_name,
            ))
            logger.debug("[%s][%s] GuestConnect: %s", server, db_name, status)

        except pyodbc.Error as exc:
            logger.warning("[%s][%s] check_guest_connect error: %s", server, db_name, exc)
            results.append(_make_result(
                run_id, server, "GuestConnect", "guest_connect",
                current=None, target="NO_CONNECT", status="ERROR",
                database=db_name, error=str(exc),
            ))

    return results


# ── Check 4: Orphaned Database Users ──────────────────────────────────────

def check_orphaned_users(
    conn: pyodbc.Connection,
    server: str,
    run_id: uuid.UUID,
) -> list[AuditResult]:
    """
    Detects database-level users that have no corresponding server-level login
    (i.e., their SID does not match any row in sys.server_principals).
    Certificate-mapped / asymmetric key users are intentionally excluded.
    """
    results: list[AuditResult] = []
    databases = list_user_databases(conn)

    for db_name in databases:
        sql = """
            SELECT dp.name AS orphan_name
            FROM   [{db}].sys.database_principals dp
            WHERE  dp.type    IN ('S', 'U', 'G')        -- SQL / Windows / Group users
              AND  dp.sid     IS NOT NULL
              AND  dp.sid     != 0x00
              AND  dp.name    NOT IN ('dbo','guest','INFORMATION_SCHEMA','sys')
              AND  NOT EXISTS (
                    SELECT 1
                    FROM   sys.server_principals sp
                    WHERE  sp.sid = dp.sid
              )
        """.replace("{db}", db_name)

        try:
            cursor = conn.cursor()
            cursor.execute(sql)
            orphans = [row.orphan_name for row in cursor.fetchall()]

            if orphans:
                for orphan in orphans:
                    results.append(_make_result(
                        run_id, server, "OrphanedUser",
                        f"orphaned_db_user::{orphan}",
                        current=f"ORPHAN:{orphan}", target="NO_ORPHAN",
                        status="DRIFT", database=db_name,
                    ))
                    logger.debug("[%s][%s] Orphan found: %s", server, db_name, orphan)
            else:
                # One PASS row per clean database
                results.append(_make_result(
                    run_id, server, "OrphanedUser", "orphaned_db_user",
                    current="NO_ORPHAN", target="NO_ORPHAN",
                    status="PASS", database=db_name,
                ))

        except pyodbc.Error as exc:
            logger.warning("[%s][%s] check_orphaned_users error: %s", server, db_name, exc)
            results.append(_make_result(
                run_id, server, "OrphanedUser", "orphaned_db_user",
                current=None, target="NO_ORPHAN", status="ERROR",
                database=db_name, error=str(exc),
            ))

    return results


# ── Master audit runner for one server ────────────────────────────────────

def audit_server(
    conn: pyodbc.Connection,
    server: str,
    run_id: uuid.UUID,
) -> list[AuditResult]:
    """Run all four check families against an open connection."""
    all_results: list[AuditResult] = []

    logger.info("  ▶ [%s] Checking server configurations …", server)
    all_results.extend(check_server_configs(conn, server, run_id))

    logger.info("  ▶ [%s] Checking XP procedure permissions …", server)
    all_results.extend(check_xp_permissions(conn, server, run_id))

    logger.info("  ▶ [%s] Checking guest CONNECT permissions …", server)
    all_results.extend(check_guest_connect(conn, server, run_id))

    logger.info("  ▶ [%s] Checking for orphaned users …", server)
    all_results.extend(check_orphaned_users(conn, server, run_id))

    return all_results
