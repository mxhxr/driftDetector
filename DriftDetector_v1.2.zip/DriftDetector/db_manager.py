# =============================================================
#  db_manager.py  –  All pyodbc connectivity & persistence
# =============================================================
from __future__ import annotations

import logging
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Generator

import pyodbc

import config

logger = logging.getLogger(__name__)


# ── Connection string helpers ──────────────────────────────────────────────

def _build_conn_str(
    server: str,
    database: str,
    trusted: bool,
    sql_user: str,
    sql_pwd: str,
    driver: str,
    timeout: int,
) -> str:
    base = (
        f"DRIVER={{{driver}}};"
        f"SERVER={server};"
        f"DATABASE={database};"
        f"Connect Timeout={timeout};"
        "ApplicationIntent=ReadOnly;"
        "APP=DriftDetector;"
    )
    if trusted:
        return base + "Trusted_Connection=yes;"
    return base + f"UID={sql_user};PWD={sql_pwd};"


def _repo_conn_str() -> str:
    r = config.REPO_DB
    return _build_conn_str(
        server=r["server"],
        database=r["database"],
        trusted=r["trusted"],
        sql_user=r["sql_user"],
        sql_pwd=r["sql_pwd"],
        driver=r["driver"],
        timeout=r["timeout"],
    )


def _audit_conn_str(server: str) -> str:
    a = config.AUDIT_CONN
    return _build_conn_str(
        server=server,
        database="master",
        trusted=a["trusted"],
        sql_user=a["sql_user"],
        sql_pwd=a["sql_pwd"],
        driver=a["driver"],
        timeout=a["timeout"],
    )


# ── Context-managed connections ────────────────────────────────────────────

@contextmanager
def get_repo_conn() -> Generator[pyodbc.Connection, None, None]:
    """Yields an auto-commit connection to the central repository."""
    conn = pyodbc.connect(_repo_conn_str(), autocommit=True)
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def get_audit_conn(server: str) -> Generator[pyodbc.Connection, None, None]:
    """Yields a read-only connection to an audit target server."""
    conn = pyodbc.connect(_audit_conn_str(server), autocommit=True)
    try:
        yield conn
    finally:
        conn.close()


# ── Baseline retrieval ─────────────────────────────────────────────────────

@dataclass(frozen=True)
class Baseline:
    check_category: str
    check_item: str
    target_value: str
    comparison_operator: str
    cis_control: str
    remediation: str


def load_baselines() -> dict[tuple[str, str], Baseline]:
    """
    Fetch all active baselines from the repo.
    Returns a dict keyed by (CheckCategory, CheckItem).
    """
    sql = """
        SELECT CheckCategory, CheckItem, TargetValue,
               ComparisonOperator, CISControl, Remediation
        FROM   dbo.CIS_Baselines
        WHERE  IsActive = 1
    """
    baselines: dict[tuple[str, str], Baseline] = {}
    with get_repo_conn() as conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        for row in cursor.fetchall():
            key = (row.CheckCategory, row.CheckItem)
            baselines[key] = Baseline(
                check_category=row.CheckCategory,
                check_item=row.CheckItem,
                target_value=row.TargetValue,
                comparison_operator=row.ComparisonOperator,
                cis_control=row.CISControl or "",
                remediation=row.Remediation or "",
            )
    logger.info("Loaded %d active baselines from repository.", len(baselines))
    return baselines


# ── Audit result persistence ───────────────────────────────────────────────

@dataclass
class AuditResult:
    run_id: uuid.UUID
    server_name: str
    database_name: str | None
    check_category: str
    check_item: str
    current_value: str | None
    target_value: str | None
    status: str                # PASS | DRIFT | ERROR | SKIPPED
    error_message: str | None = None


def persist_results(results: list[AuditResult], dry_run: bool = False) -> None:
    """
    Bulk-insert AuditResult rows into Fact_Audit_History.
    Skipped entirely in dry-run mode.
    """
    if dry_run:
        logger.info("[DRY RUN] Skipping DB write for %d result rows.", len(results))
        return

    if not results:
        logger.debug("No results to persist.")
        return

    sql = """
        INSERT INTO dbo.Fact_Audit_History
            (RunID, ServerName, DatabaseName, CheckCategory, CheckItem,
             CurrentValue, TargetValue, Status, ErrorMessage)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    rows = [
        (
            str(r.run_id),
            r.server_name,
            r.database_name,
            r.check_category,
            r.check_item,
            r.current_value,
            r.target_value,
            r.status,
            r.error_message,
        )
        for r in results
    ]

    with get_repo_conn() as conn:
        conn.autocommit = False
        try:
            cursor = conn.cursor()
            cursor.fast_executemany = True
            cursor.executemany(sql, rows)
            conn.commit()
            logger.info("Persisted %d audit result rows.", len(rows))
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.autocommit = True


def list_user_databases(audit_conn: pyodbc.Connection) -> list[str]:
    """Returns all non-system, online databases from a target server."""
    sql = """
        SELECT name
        FROM   sys.databases
        WHERE  state_desc = 'ONLINE'
          AND  name NOT IN ({placeholders})
        ORDER  BY name
    """.format(
        placeholders=",".join("?" * len(config.SYSTEM_DATABASES))
    )
    cursor = audit_conn.cursor()
    cursor.execute(sql, list(config.SYSTEM_DATABASES))
    return [row.name for row in cursor.fetchall()]
