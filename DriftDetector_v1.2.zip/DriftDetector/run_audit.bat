@echo off
:: ================================================================
::  run_audit.bat  —  DriftDetector Live Audit (headless)
::  Uses portable Python in python\ if present.
:: ================================================================
setlocal
set ROOT=%~dp0

if exist "%ROOT%settings.env" (
    for /f "usebackq tokens=1,* delims==" %%A in ("%ROOT%settings.env") do (
        if not "%%A"=="" if not "%%A:~0,1%"=="#" set "%%A=%%B"
    )
)

call "%ROOT%_python.bat"
if %errorlevel% neq 0 ( pause & exit /b 1 )

cd /d "%ROOT%"
title DriftDetector — Running Audit...

echo.
echo  =========================================
echo   DriftDetector — SQL Server CIS Audit
echo  =========================================
echo   Python : %PYEXE%
echo   Mode   : LIVE (results written to DB)
echo   Time   : %date% %time%
echo  =========================================
echo.

"%PYEXE%" main.py %*

set EXIT_CODE=%errorlevel%
echo.
if %EXIT_CODE%==0   ( echo  [OK]  All checks passed. )
if %EXIT_CODE%==2   ( echo  [!!]  Drift detected — check reports\ for the Excel file. )
if %EXIT_CODE%==1   ( echo  [ERR] Fatal error — check logs\ for details. )
echo.
echo  Press any key to close...
pause >nul
exit /b %EXIT_CODE%
