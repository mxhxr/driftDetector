-- ============================================================
--  SQL Server Configuration Drift Detection
--  Backend Schema DDL
--  CIS Benchmark Compliance-as-Code
-- ============================================================

USE [DriftDetector];   -- change to your target DB
GO

-- ============================================================
--  TABLE: CIS_Baselines
--  Stores the "Gold Standard" target value for each check.
--  Populated once via the INSERT block at the bottom.
-- ============================================================
IF OBJECT_ID(N'dbo.CIS_Baselines', N'U') IS NOT NULL
    DROP TABLE dbo.CIS_Baselines;
GO

CREATE TABLE dbo.CIS_Baselines (
    BaselineID          INT             IDENTITY(1,1)   NOT NULL,
    CheckCategory       NVARCHAR(100)   NOT NULL,       -- e.g. 'ServerConfig', 'XPPermission', 'GuestConnect', 'OrphanedUser'
    CheckItem           NVARCHAR(255)   NOT NULL,       -- e.g. 'scan for startup procs'
    TargetValue         NVARCHAR(500)   NOT NULL,       -- e.g. '0', 'REVOKED', 'NO_CONNECT', 'NO_ORPHAN'
    ComparisonOperator  NVARCHAR(20)    NOT NULL        -- 'EQUALS' | 'GTE' | 'PRESENCE_BAD' | 'ABSENCE_GOOD'
        CONSTRAINT CK_Baselines_Operator CHECK (
            ComparisonOperator IN ('EQUALS','GTE','PRESENCE_BAD','ABSENCE_GOOD')
        ),
    CISControl          NVARCHAR(100)   NULL,           -- e.g. 'CIS SQL Server 2019 - 2.1'
    Remediation         NVARCHAR(1000)  NULL,
    IsActive            BIT             NOT NULL CONSTRAINT DF_Baselines_IsActive DEFAULT (1),
    CreatedAt           DATETIME2(0)    NOT NULL CONSTRAINT DF_Baselines_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_CIS_Baselines PRIMARY KEY CLUSTERED (BaselineID),
    CONSTRAINT UQ_CIS_Baselines_Item      UNIQUE (CheckCategory, CheckItem)
);
GO

-- ============================================================
--  TABLE: Fact_Audit_History
--  Append-only log of every check result from every run.
-- ============================================================
IF OBJECT_ID(N'dbo.Fact_Audit_History', N'U') IS NOT NULL
    DROP TABLE dbo.Fact_Audit_History;
GO

CREATE TABLE dbo.Fact_Audit_History (
    AuditID         BIGINT          IDENTITY(1,1)   NOT NULL,
    RunID           UNIQUEIDENTIFIER NOT NULL,        -- groups all rows from one execution
    AuditTimestamp  DATETIME2(3)    NOT NULL CONSTRAINT DF_Audit_Timestamp DEFAULT SYSUTCDATETIME(),
    ServerName      NVARCHAR(255)   NOT NULL,
    DatabaseName    NVARCHAR(255)   NULL,             -- NULL for instance-level checks
    CheckCategory   NVARCHAR(100)   NOT NULL,
    CheckItem       NVARCHAR(255)   NOT NULL,
    CurrentValue    NVARCHAR(500)   NULL,
    TargetValue     NVARCHAR(500)   NULL,
    Status          NVARCHAR(20)    NOT NULL
        CONSTRAINT CK_Audit_Status CHECK (Status IN ('PASS','DRIFT','ERROR','SKIPPED')),
    ErrorMessage    NVARCHAR(2000)  NULL,
    CONSTRAINT PK_Fact_Audit_History PRIMARY KEY CLUSTERED (AuditID)
);
GO

-- Performance indexes
CREATE NONCLUSTERED INDEX IX_Audit_RunID
    ON dbo.Fact_Audit_History (RunID)
    INCLUDE (ServerName, Status);
GO

CREATE NONCLUSTERED INDEX IX_Audit_Server_Timestamp
    ON dbo.Fact_Audit_History (ServerName, AuditTimestamp DESC)
    INCLUDE (CheckCategory, CheckItem, Status);
GO

-- ============================================================
--  SEED: CIS_Baselines Gold Standard values
-- ============================================================

INSERT INTO dbo.CIS_Baselines
    (CheckCategory, CheckItem, TargetValue, ComparisonOperator, CISControl, Remediation)
VALUES
-- ── Server Configuration ──────────────────────────────────────────────────
('ServerConfig', 'scan for startup procs', '0', 'EQUALS',
    'CIS SQL Server 2019 Benchmark - 2.1',
    'EXEC sp_configure ''scan for startup procs'', 0; RECONFIGURE WITH OVERRIDE;'),

('ServerConfig', 'SQL Mail XPs', '0', 'EQUALS',
    'CIS SQL Server 2019 Benchmark - 2.2',
    'EXEC sp_configure ''SQL Mail XPs'', 0; RECONFIGURE WITH OVERRIDE;'),

('ServerConfig', 'max number of error logs', '12', 'GTE',
    'CIS SQL Server 2019 Benchmark - 2.4',
    'EXEC xp_instance_regwrite N''HKEY_LOCAL_MACHINE'', N''Software\Microsoft\MSSQLServer\MSSQLServer'', N''NumErrorLogs'', REG_DWORD, 12;'),

-- ── Extended Stored Procedure PUBLIC Permissions ──────────────────────────
('XPPermission', 'xp_availablemedia',    'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.1', 'REVOKE EXECUTE ON xp_availablemedia FROM PUBLIC;'),
('XPPermission', 'xp_dirtree',           'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.2', 'REVOKE EXECUTE ON xp_dirtree FROM PUBLIC;'),
('XPPermission', 'xp_enumgroups',        'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.3', 'REVOKE EXECUTE ON xp_enumgroups FROM PUBLIC;'),
('XPPermission', 'xp_fixeddrives',       'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.4', 'REVOKE EXECUTE ON xp_fixeddrives FROM PUBLIC;'),
('XPPermission', 'xp_servicecontrol',    'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.5', 'REVOKE EXECUTE ON xp_servicecontrol FROM PUBLIC;'),
('XPPermission', 'xp_subdirs',           'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.6', 'REVOKE EXECUTE ON xp_subdirs FROM PUBLIC;'),
('XPPermission', 'xp_regaddmultistring', 'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.7', 'REVOKE EXECUTE ON xp_regaddmultistring FROM PUBLIC;'),
('XPPermission', 'xp_regdeletekey',      'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.8', 'REVOKE EXECUTE ON xp_regdeletekey FROM PUBLIC;'),
('XPPermission', 'xp_regdeletevalue',    'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.9', 'REVOKE EXECUTE ON xp_regdeletevalue FROM PUBLIC;'),
('XPPermission', 'xp_regenumvalues',     'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.10', 'REVOKE EXECUTE ON xp_regenumvalues FROM PUBLIC;'),
('XPPermission', 'xp_regremovemultistring','REVOKED','PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.11', 'REVOKE EXECUTE ON xp_regremovemultistring FROM PUBLIC;'),
('XPPermission', 'xp_regwrite',          'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.12', 'REVOKE EXECUTE ON xp_regwrite FROM PUBLIC;'),
('XPPermission', 'xp_regread',           'REVOKED', 'PRESENCE_BAD',
    'CIS SQL Server 2019 Benchmark - 3.13', 'REVOKE EXECUTE ON xp_regread FROM PUBLIC;'),

-- ── Guest Connect Permission ───────────────────────────────────────────────
('GuestConnect', 'guest_connect', 'NO_CONNECT', 'ABSENCE_GOOD',
    'CIS SQL Server 2019 Benchmark - 4.2',
    'USE [<DatabaseName>]; REVOKE CONNECT FROM guest;'),

-- ── Orphaned Users ─────────────────────────────────────────────────────────
('OrphanedUser', 'orphaned_db_user', 'NO_ORPHAN', 'ABSENCE_GOOD',
    'CIS SQL Server 2019 Benchmark - 4.3',
    'USE [<DatabaseName>]; DROP USER [<UserName>]; -- or re-map: ALTER USER [<UserName>] WITH LOGIN = [<LoginName>];');
GO

-- Quick verification
SELECT CheckCategory, COUNT(*) AS CheckCount
FROM   dbo.CIS_Baselines
GROUP  BY CheckCategory
ORDER  BY CheckCategory;
GO
