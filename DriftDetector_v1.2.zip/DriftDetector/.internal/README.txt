This folder contains internal files used by setup.ps1 and the application.
Do not edit these files directly.

schema.sql  — SQL DDL for the CIS_Baselines and Fact_Audit_History tables.
              Run setup.ps1 to deploy automatically, or open in SSMS manually.
