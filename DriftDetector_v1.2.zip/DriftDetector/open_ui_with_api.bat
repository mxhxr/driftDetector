@echo off
:: ================================================================
::  open_ui_with_api.bat  —  DriftDetector Full Launch
::  Uses portable Python in python\ if present,
::  otherwise falls back to system Python.
:: ================================================================
setlocal EnableDelayedExpansion
set ROOT=%~dp0

if exist "%ROOT%settings.env" (
    for /f "usebackq tokens=1,* delims==" %%A in ("%ROOT%settings.env") do (
        if not "%%A"=="" if not "%%A:~0,1%"=="#" set "%%A=%%B"
    )
)

call "%ROOT%_python.bat"
if %errorlevel% neq 0 ( pause & exit /b 1 )

if not exist "%ROOT%api.py" ( echo [ERR] api.py not found & pause & exit /b 1 )

cd /d "%ROOT%"
title DriftDetector Launcher

echo.
echo  ================================================================
echo   DriftDetector — Starting
echo  ================================================================
echo   Python : %PYEXE%
echo   API    : http://127.0.0.1:5050
echo  ================================================================
echo.

start "DriftDetector API Server  [http://127.0.0.1:5050 - keep open]" ^
    cmd /k "title DriftDetector API [keep open] && cd /d %ROOT% && %PYEXE% api.py"

echo  Waiting for API...
set /a TRIES=0
:WAIT
timeout /t 1 /nobreak >nul
set /a TRIES+=1
"%PYEXE%" -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:5050/api/health',timeout=1)" >nul 2>&1
if %errorlevel%==0 goto READY
if %TRIES% lss 10 goto WAIT
echo  [!!]  API slow to start — opening UI anyway.
goto OPEN
:READY
echo  [OK]  API is online.
:OPEN
echo  Opening dashboard...
start "" "%ROOT%drift_detector_ui.html"
echo.
echo  Keep the API Server window open while using the UI.
echo.
