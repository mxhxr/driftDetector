# =============================================================
#  config.py  —  DriftDetector configuration
#  All paths are relative to this file's directory so the
#  package runs from any folder without editing source code.
#  Override any value with an environment variable (see below).
# =============================================================
from __future__ import annotations
import os
from pathlib import Path

# Root of the package — always the folder this file lives in
ROOT = Path(__file__).parent.resolve()

# ── Target servers to audit ────────────────────────────────────────────────
# Populated by the UI wizard or edited directly here.
# Each entry: {"server": "<hostname or hostname\\instance>"}
TARGET_SERVERS: list[dict] = [
    # {"server": "SQLPROD01"},
    # {"server": "SQLPROD02\\INST1"},
]

# ── Central repository DB ──────────────────────────────────────────────────
REPO_DB = {
    "server":   os.getenv("DRIFT_REPO_SERVER", ""),          # e.g. SQLPROD01
    "database": os.getenv("DRIFT_REPO_DB",     "DriftDetector"),
    "trusted":  os.getenv("DRIFT_TRUSTED",     "1") == "1",  # Windows Auth
    "sql_user": os.getenv("DRIFT_SQL_USER",    ""),
    "sql_pwd":  os.getenv("DRIFT_SQL_PWD",     ""),
    "driver":   os.getenv("DRIFT_ODBC_DRIVER", "ODBC Driver 17 for SQL Server"),
    "timeout":  int(os.getenv("DRIFT_CONN_TIMEOUT", "30")),
}

# ── Audit target connection defaults ──────────────────────────────────────
AUDIT_CONN = {
    "trusted":  os.getenv("DRIFT_TRUSTED",      "1") == "1",
    "sql_user": os.getenv("DRIFT_AUDIT_USER",   ""),
    "sql_pwd":  os.getenv("DRIFT_AUDIT_PWD",    ""),
    "driver":   os.getenv("DRIFT_ODBC_DRIVER",  "ODBC Driver 17 for SQL Server"),
    "timeout":  int(os.getenv("DRIFT_CONN_TIMEOUT", "30")),
}

# ── Databases excluded from guest / orphan checks ─────────────────────────
SYSTEM_DATABASES: set[str] = {"master", "msdb", "tempdb", "model", "distribution"}

# ── Output — relative to package root ─────────────────────────────────────
REPORTS_DIR = ROOT / os.getenv("DRIFT_REPORTS_DIR", "reports")
LOGS_DIR    = ROOT / "logs"
REPORTS_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True,    exist_ok=True)

LOG_LEVEL = os.getenv("DRIFT_LOG_LEVEL", "INFO")

# ── Runtime flags ─────────────────────────────────────────────────────────
DRY_RUN:   bool = False
FAIL_FAST: bool = False
