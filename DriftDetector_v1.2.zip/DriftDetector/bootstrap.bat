@echo off
:: ================================================================
::  bootstrap.bat  —  DriftDetector One-Time Setup
::
::  Downloads the Python embeddable runtime and all dependencies
::  into this folder.  No admin rights.  No system-wide install.
::  Run this ONCE, then use open_ui_with_api.bat forever after.
::
::  Requires:  Internet connection (one time only)
::             Windows 10/11 x64
::             PowerShell 5+ (built into Windows)
:: ================================================================
@setlocal EnableDelayedExpansion
set ROOT=%~dp0
set PYDIR=%ROOT%python
set PYEXE=%PYDIR%\python.exe
set PIPEXE=%PYDIR%\Scripts\pip.exe

title DriftDetector — Bootstrap Setup

echo.
echo  ================================================================
echo   DriftDetector — Portable Bootstrap Setup
echo  ================================================================
echo   This will download Python and all required packages into:
echo   %PYDIR%
echo.
echo   Nothing will be installed system-wide.
echo   Estimated download: ~35 MB  (one-time only)
echo  ================================================================
echo.

:: ── Check if already bootstrapped ────────────────────────────────
if exist "%PYEXE%" (
    echo  [OK]  Embedded Python already present.
    goto :CHECK_PACKAGES
)

:: ── Download Python embeddable distribution ───────────────────────
echo  [1/4] Downloading Python 3.12 embeddable runtime...
echo        (from python.org — ~12 MB)
echo.

set PY_URL=https://www.python.org/ftp/python/3.12.9/python-3.12.9-embed-amd64.zip
set PY_ZIP=%TEMP%\py_embed.zip

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; ^
   $ProgressPreference='SilentlyContinue'; ^
   Invoke-WebRequest -Uri '%PY_URL%' -OutFile '%PY_ZIP%' -UseBasicParsing"

if not exist "%PY_ZIP%" (
    echo.
    echo  [ERR] Download failed. Check your internet connection.
    echo        You can also manually download:
    echo        %PY_URL%
    echo        Extract it to:  %PYDIR%
    pause & exit /b 1
)
echo  [OK]  Downloaded.

:: ── Extract Python ─────────────────────────────────────────────────
echo  [2/4] Extracting Python runtime...
if not exist "%PYDIR%" mkdir "%PYDIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Expand-Archive -Path '%PY_ZIP%' -DestinationPath '%PYDIR%' -Force"
del /f /q "%PY_ZIP%" 2>nul
if not exist "%PYEXE%" (
    echo  [ERR] Extraction failed.
    pause & exit /b 1
)
echo  [OK]  Python extracted to python\

:: ── Copy sitecustomize.py into the runtime ───────────────────────────
echo  Copying sitecustomize helper...
if exist "%ROOT%sitecustomize.py" (
    copy /y "%ROOT%sitecustomize.py" "%PYDIR%\sitecustomize.py" >nul
    echo  [OK]  sitecustomize.py installed.
)

:: ── Enable site-packages and pip in the embeddable distribution ───
:: The ._pth file in the embed zip by default has `import site` commented out.
:: We must uncomment it so that pip-installed packages are found.
echo  [3/4] Configuring Python runtime for package support...

set PTH_FILE=
for %%f in ("%PYDIR%\python*._pth") do set PTH_FILE=%%f

if defined PTH_FILE (
    :: Replace '#import site' with 'import site' and add Lib\site-packages
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
      "$p='%PTH_FILE%'; $c=Get-Content $p -Raw; ^
       $c=$c -replace '#import site','import site'; ^
       Set-Content $p $c -NoNewline"
    echo  [OK]  site-packages enabled.
) else (
    echo  [!!]  Could not find ._pth file — packages may not load correctly.
)

:: ── Bootstrap pip ─────────────────────────────────────────────────
echo  [4/4] Installing pip and required packages...
echo        (pyodbc, pandas, openpyxl, flask, flask-cors — ~22 MB)
echo.

:: Download get-pip.py
set GETPIP=%TEMP%\get-pip.py
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; ^
   $ProgressPreference='SilentlyContinue'; ^
   Invoke-WebRequest -Uri 'https://bootstrap.pypa.io/get-pip.py' -OutFile '%GETPIP%' -UseBasicParsing"

if not exist "%GETPIP%" (
    echo  [ERR] Could not download get-pip.py
    pause & exit /b 1
)

"%PYEXE%" "%GETPIP%" --quiet --no-warn-script-location
del /f /q "%GETPIP%" 2>nul

:: Install packages into the local python\ folder
:CHECK_PACKAGES
"%PYEXE%" -m pip install ^
    pyodbc ^
    pandas ^
    openpyxl ^
    flask ^
    flask-cors ^
    --target="%PYDIR%\Lib\site-packages" ^
    --quiet ^
    --no-warn-script-location ^
    --disable-pip-version-check

if %errorlevel% neq 0 (
    echo.
    echo  [!!]  pip install reported errors. Some packages may be missing.
    echo        Try running bootstrap.bat again, or check your connection.
    echo.
    pause & exit /b 1
)
echo  [OK]  All packages installed.

:: ── Verify critical imports ────────────────────────────────────────
echo.
echo  Verifying installation...
"%PYEXE%" -c "import pyodbc, pandas, openpyxl, flask, flask_cors; print('  [OK]  All packages verified.')"
if %errorlevel% neq 0 (
    echo  [!!]  Verification failed — some packages may not have installed correctly.
    pause & exit /b 1
)

:: ── Check ODBC Driver ──────────────────────────────────────────────
echo.
echo  Checking ODBC drivers...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d=Get-OdbcDriver | Where-Object{$_.Name -like '*SQL Server*'} | Select-Object -ExpandProperty Name; ^
   if($d){$d|ForEach-Object{Write-Host '  [OK]  Found: '$_}} ^
   else{Write-Host '  [!!]  No SQL Server ODBC driver found.' -ForegroundColor Yellow; ^
        Write-Host '        Download: https://aka.ms/downloadmsodbcsql' -ForegroundColor Gray}"

:: ── Write the settings.env placeholder if missing ─────────────────
if not exist "%ROOT%settings.env" (
    echo.> "%ROOT%settings.env"
    echo # DriftDetector Runtime Settings>> "%ROOT%settings.env"
    echo DRIFT_REPO_SERVER=>> "%ROOT%settings.env"
    echo DRIFT_REPO_DB=DriftDetector>> "%ROOT%settings.env"
    echo DRIFT_TRUSTED=1>> "%ROOT%settings.env"
    echo DRIFT_SQL_USER=>> "%ROOT%settings.env"
    echo DRIFT_SQL_PWD=>> "%ROOT%settings.env"
    echo DRIFT_ODBC_DRIVER=ODBC Driver 17 for SQL Server>> "%ROOT%settings.env"
    echo DRIFT_CONN_TIMEOUT=30>> "%ROOT%settings.env"
    echo DRIFT_LOG_LEVEL=INFO>> "%ROOT%settings.env"
    echo  [OK]  Created settings.env
)

:: ── Create output folders ──────────────────────────────────────────
if not exist "%ROOT%reports" mkdir "%ROOT%reports"
if not exist "%ROOT%logs"    mkdir "%ROOT%logs"
if not exist "%ROOT%data"    mkdir "%ROOT%data"

:: ── Done ───────────────────────────────────────────────────────────
echo.
echo  ================================================================
echo   Bootstrap complete!
echo  ================================================================
echo.
echo   What to do next:
echo.
echo   1. Edit settings.env — set DRIFT_REPO_SERVER to your
echo      central SQL Server, then deploy the schema:
echo      open .internal\schema.sql in SSMS and execute it.
echo.
echo   2. Double-click  open_ui_with_api.bat  to launch the
echo      dashboard. Configure servers in the UI, then run
echo      your first audit from the Run Audit panel.
echo.
echo   Everything runs from this folder.
echo   No Python installation required on any other machine —
echo   just copy the whole folder.
echo.
pause
