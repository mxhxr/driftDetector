@echo off
:: ================================================================
::  open_ui.bat  —  Open the dashboard (API must already be running)
::  Use open_ui_with_api.bat to start both together.
:: ================================================================
echo  Note: For full live functionality use open_ui_with_api.bat
echo  which starts the API server automatically.
echo.
start "" "%~dp0drift_detector_ui.html"
