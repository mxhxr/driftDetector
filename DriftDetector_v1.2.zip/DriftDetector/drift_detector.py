# =============================================================
#  drift_detector.py  –  Pandas-based drift comparison engine
# =============================================================
from __future__ import annotations

import logging
from dataclasses import asdict

import pandas as pd

from db_manager import AuditResult, Baseline

logger = logging.getLogger(__name__)

# Canonical column order for the drift DataFrame
DRIFT_COLUMNS: list[str] = [
    "run_id",
    "server_name",
    "database_name",
    "check_category",
    "check_item",
    "current_value",
    "target_value",
    "status",
    "error_message",
    "cis_control",
    "remediation",
]

# Human-readable category labels for reports
CATEGORY_LABELS: dict[str, str] = {
    "ServerConfig":  "Server Configuration",
    "XPPermission":  "XP Proc PUBLIC Permission",
    "GuestConnect":  "Guest CONNECT Permission",
    "OrphanedUser":  "Orphaned Database User",
}


def results_to_dataframe(
    results: list[AuditResult],
    baselines: dict[tuple[str, str], Baseline],
) -> pd.DataFrame:
    """
    Converts raw AuditResult objects to a DataFrame, enriched with
    baseline metadata (CISControl, Remediation) for reporting.
    Baseline lookup uses (CheckCategory, base CheckItem) – strips the
    '::username' suffix used for per-orphan rows.
    """
    if not results:
        return pd.DataFrame(columns=DRIFT_COLUMNS)

    rows = [asdict(r) for r in results]
    df = pd.DataFrame(rows)
    df["run_id"] = df["run_id"].astype(str)

    # Enrich with baseline metadata
    def _get_baseline_field(row: pd.Series, field: str) -> str:
        base_item = row["check_item"].split("::")[0]          # strip orphan suffix
        bl = baselines.get((row["check_category"], base_item))
        if bl is None:
            # try wildcard for dynamic check_item keys
            bl = baselines.get((row["check_category"], "orphaned_db_user"))
        return getattr(bl, field, "") if bl else ""

    df["cis_control"]  = df.apply(_get_baseline_field, axis=1, field="cis_control")
    df["remediation"]  = df.apply(_get_baseline_field, axis=1, field="remediation")

    # Friendly category label
    df["category_label"] = df["check_category"].map(
        lambda c: CATEGORY_LABELS.get(c, c)
    )

    return df[DRIFT_COLUMNS + ["category_label"]]


def extract_drifts(df: pd.DataFrame) -> pd.DataFrame:
    """Returns only rows where status == 'DRIFT', sorted for readability."""
    if df.empty:
        return df
    drift_df = df[df["status"] == "DRIFT"].copy()
    drift_df.sort_values(
        ["server_name", "check_category", "check_item", "database_name"],
        inplace=True,
        na_position="last",
    )
    return drift_df.reset_index(drop=True)


def summarise_run(df: pd.DataFrame) -> dict:
    """Returns a quick-stats dict for logging / report header."""
    if df.empty:
        return {"total": 0, "pass": 0, "drift": 0, "error": 0, "skipped": 0}
    counts = df["status"].value_counts().to_dict()
    return {
        "total":   len(df),
        "pass":    counts.get("PASS",    0),
        "drift":   counts.get("DRIFT",   0),
        "error":   counts.get("ERROR",   0),
        "skipped": counts.get("SKIPPED", 0),
    }


def per_server_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Pivot table: server × status for the executive summary sheet."""
    if df.empty:
        return pd.DataFrame()
    pivot = (
        df.groupby(["server_name", "status"])
        .size()
        .unstack(fill_value=0)
        .reset_index()
    )
    # Ensure all status columns exist
    for col in ("PASS", "DRIFT", "ERROR", "SKIPPED"):
        if col not in pivot.columns:
            pivot[col] = 0
    pivot["TOTAL"] = pivot[["PASS", "DRIFT", "ERROR", "SKIPPED"]].sum(axis=1)
    pivot.rename(columns={"server_name": "Server"}, inplace=True)
    return pivot
