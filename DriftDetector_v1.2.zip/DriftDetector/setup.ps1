# ================================================================
#  setup.ps1  —  DriftDetector First-Run Setup Wizard
#  Run once after unzipping. Right-click → Run with PowerShell
#  or: powershell -ExecutionPolicy Bypass -File setup.ps1
# ================================================================
#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ROOT   = $PSScriptRoot
$BANNER = @"

  ██████╗ ██████╗ ██╗███████╗████████╗
  ██╔══██╗██╔══██╗██║██╔════╝╚══██╔══╝
  ██║  ██║██████╔╝██║█████╗     ██║
  ██║  ██║██╔══██╗██║██╔══╝     ██║
  ██████╔╝██║  ██║██║██║        ██║
  ╚═════╝ ╚═╝  ╚═╝╚═╝╚═╝        ╚═╝
  DriftDetector — SQL Server CIS Compliance
  Setup Wizard v1.0
"@

function Write-Header($text) {
    Write-Host ""
    Write-Host "  ─────────────────────────────────────────────" -ForegroundColor DarkGray
    Write-Host "  $text" -ForegroundColor Cyan
    Write-Host "  ─────────────────────────────────────────────" -ForegroundColor DarkGray
}
function Write-Ok($text)   { Write-Host "  [OK]  $text" -ForegroundColor Green  }
function Write-Warn($text) { Write-Host "  [!!]  $text" -ForegroundColor Yellow }
function Write-Err($text)  { Write-Host "  [ERR] $text" -ForegroundColor Red    }
function Write-Info($text) { Write-Host "  [--]  $text" -ForegroundColor Gray   }
function Ask($prompt, $default='') {
    $hint = if ($default) { " [$default]" } else { '' }
    Write-Host "  >>> $prompt$hint : " -ForegroundColor White -NoNewline
    $ans = Read-Host
    if ([string]::IsNullOrWhiteSpace($ans) -and $default) { return $default }
    return $ans
}
function AskYN($prompt, $default='Y') {
    $opts = if ($default -eq 'Y') { 'Y/n' } else { 'y/N' }
    Write-Host "  >>> $prompt [$opts]: " -ForegroundColor White -NoNewline
    $ans = Read-Host
    if ([string]::IsNullOrWhiteSpace($ans)) { return $default -eq 'Y' }
    return $ans -match '^[Yy]'
}

Clear-Host
Write-Host $BANNER -ForegroundColor Blue
Write-Host ""

# ── Step 1: Python ──────────────────────────────────────────────────────────
Write-Header "Step 1 of 5 — Checking Python"
try {
    $pyVer = & python --version 2>&1
    if ($pyVer -match '(\d+)\.(\d+)') {
        $maj = [int]$Matches[1]; $min = [int]$Matches[2]
        if ($maj -ge 3 -and $min -ge 12) {
            Write-Ok "Found $pyVer"
        } else {
            Write-Warn "$pyVer detected. Python 3.12+ recommended."
            Write-Info "Download: https://python.org/downloads/"
            if (-not (AskYN "Continue anyway?")) { exit 1 }
        }
    }
} catch {
    Write-Err "Python not found in PATH."
    Write-Info "Install Python 3.12+ from https://python.org/downloads/"
    Write-Info "Ensure 'Add python.exe to PATH' is checked during install."
    Read-Host "  Press Enter to exit"
    exit 1
}

# ── Step 2: pip dependencies ────────────────────────────────────────────────
Write-Header "Step 2 of 5 — Installing Python Dependencies"
Write-Info "Running: pip install -r requirements.txt"
try {
    & pip install -r "$ROOT\requirements.txt" --quiet --disable-pip-version-check
    Write-Ok "pyodbc, pandas, openpyxl installed."
} catch {
    Write-Err "pip install failed: $_"
    Write-Info "Try manually: pip install pyodbc pandas openpyxl"
    Read-Host "  Press Enter to exit"
    exit 1
}

# ── Step 3: ODBC Driver ─────────────────────────────────────────────────────
Write-Header "Step 3 of 5 — Checking ODBC Driver"
$drivers = Get-OdbcDriver | Where-Object { $_.Name -like '*SQL Server*' } | Select-Object -ExpandProperty Name
if ($drivers) {
    $drivers | ForEach-Object { Write-Ok "Found: $_" }
    $preferredDriver = ($drivers | Where-Object { $_ -like 'ODBC Driver 1*' } | Sort-Object -Descending | Select-Object -First 1)
    if (-not $preferredDriver) { $preferredDriver = $drivers[0] }
    Write-Info "Will use: $preferredDriver"
} else {
    Write-Warn "No SQL Server ODBC driver found!"
    Write-Info "Download ODBC Driver 17: https://aka.ms/downloadmsodbcsql"
    if (-not (AskYN "Continue without ODBC driver (you must install it before running)?")) { exit 1 }
    $preferredDriver = 'ODBC Driver 17 for SQL Server'
}

# ── Step 4: Repository database ─────────────────────────────────────────────
Write-Header "Step 4 of 5 — Repository Database Configuration"
Write-Info "This is the central SQL Server that stores baselines and audit history."
Write-Info "It can be the same server as one of your audit targets."
Write-Host ""

$repoServer = Ask "Repository SQL Server hostname or IP"
$repoDB     = Ask "Repository database name" "DriftDetector"
$authType   = Ask "Authentication: (W)indows Integrated or (S)QL Server auth?" "W"
$sqlUser    = ''
$sqlPwd     = ''
if ($authType -match '^[Ss]') {
    $sqlUser = Ask "SQL Username"
    $secPwd  = Read-Host "  >>> SQL Password" -AsSecureString
    $sqlPwd  = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
                   [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secPwd))
}

# Write settings.env
$envContent = @"
# DriftDetector runtime settings
# Generated by setup.ps1 — edit as needed
DRIFT_REPO_SERVER=$repoServer
DRIFT_REPO_DB=$repoDB
DRIFT_TRUSTED=$( if ($authType -match '^[Ww]') { '1' } else { '0' } )
DRIFT_SQL_USER=$sqlUser
DRIFT_SQL_PWD=$sqlPwd
DRIFT_ODBC_DRIVER=$preferredDriver
DRIFT_CONN_TIMEOUT=30
DRIFT_LOG_LEVEL=INFO
"@
$envContent | Set-Content "$ROOT\settings.env" -Encoding UTF8
Write-Ok "settings.env written."

# ── Step 5: Schema deployment ────────────────────────────────────────────────
Write-Header "Step 5 of 5 — Deploy Database Schema"
Write-Info "The schema creates CIS_Baselines and Fact_Audit_History tables."
Write-Host ""

$deploySql = AskYN "Deploy schema to $repoServer\$repoDB now?" "Y"
if ($deploySql) {
    # Find sqlcmd
    $sqlcmd = Get-Command sqlcmd -ErrorAction SilentlyContinue
    if (-not $sqlcmd) {
        $sqlcmd = Get-Item 'C:\Program Files\Microsoft SQL Server\*\Tools\Binn\sqlcmd.exe' `
                           -ErrorAction SilentlyContinue | Sort-Object | Select-Object -Last 1
    }
    if ($sqlcmd) {
        Write-Info "Using sqlcmd: $($sqlcmd.Source ?? $sqlcmd.FullName)"
        try {
            # Create DB if not exists
            $createDbSql = "IF DB_ID('$repoDB') IS NULL CREATE DATABASE [$repoDB];"
            if ($authType -match '^[Ww]') {
                & sqlcmd -S $repoServer -Q $createDbSql -b | Out-Null
                & sqlcmd -S $repoServer -d $repoDB -i "$ROOT\.internal\schema.sql" -b
            } else {
                & sqlcmd -S $repoServer -U $sqlUser -P $sqlPwd -Q $createDbSql -b | Out-Null
                & sqlcmd -S $repoServer -U $sqlUser -P $sqlPwd -d $repoDB -i "$ROOT\.internal\schema.sql" -b
            }
            Write-Ok "Schema deployed successfully."
        } catch {
            Write-Err "sqlcmd failed: $_"
            Write-Warn "Run .internal\schema.sql manually in SSMS against $repoServer\$repoDB"
        }
    } else {
        Write-Warn "sqlcmd not found. Run the schema manually."
        Write-Info "Open SSMS → connect to $repoServer → open .internal\schema.sql → Execute"
    }
} else {
    Write-Warn "Skipped. Remember to run .internal\schema.sql in SSMS before first audit."
}

# ── Dry-run verification ─────────────────────────────────────────────────────
Write-Host ""
Write-Header "Setup Complete!"
Write-Host ""
Write-Ok "All steps finished. Your package is ready."
Write-Host ""
Write-Info "What to do next:"
Write-Host ""
Write-Host "  1. Open the UI        : double-click  open_ui.bat" -ForegroundColor White
Write-Host "     → Go to Target Servers → add servers or import from SQL table" -ForegroundColor Gray
Write-Host "     → Go to Settings   → confirm repo connection" -ForegroundColor Gray
Write-Host ""
Write-Host "  2. Dry-run test       : double-click  dry_run.bat" -ForegroundColor White
Write-Host "     → Audits all targets, writes no DB rows, saves report to reports\" -ForegroundColor Gray
Write-Host ""
Write-Host "  3. Schedule           : double-click  schedule_task.bat (run as Administrator)" -ForegroundColor White
Write-Host ""
Write-Host "  4. Live audit         : double-click  run_audit.bat" -ForegroundColor White
Write-Host ""
Read-Host "  Press Enter to close"
