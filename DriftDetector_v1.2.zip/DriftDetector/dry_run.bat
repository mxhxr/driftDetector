@echo off
:: ================================================================
::  dry_run.bat  —  DriftDetector Safe Test (no DB writes)
::  Uses portable Python in python\ if present.
:: ================================================================
setlocal
set ROOT=%~dp0

if exist "%ROOT%settings.env" (
    for /f "usebackq tokens=1,* delims==" %%A in ("%ROOT%settings.env") do (
        if not "%%A"=="" if not "%%A:~0,1%"=="#" set "%%A=%%B"
    )
)

call "%ROOT%_python.bat"
if %errorlevel% neq 0 ( pause & exit /b 1 )

cd /d "%ROOT%"
title DriftDetector — Dry Run

echo.
echo  =========================================
echo   DriftDetector — DRY RUN
echo  =========================================
echo   Python : %PYEXE%
echo   Mode   : DRY RUN (no database writes)
echo   Time   : %date% %time%
echo  =========================================
echo.

"%PYEXE%" main.py --dry-run %*

set EXIT_CODE=%errorlevel%
echo.
echo  Dry run complete. Report saved to reports\
echo  No data was written to the repository database.
echo.
echo  Press any key to close...
pause >nul
exit /b %EXIT_CODE%
