# =============================================================
#  reporter.py  –  Timestamped Excel report via openpyxl
# =============================================================
from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import (
    Alignment, Border, Font, GradientFill, PatternFill, Side,
)
from openpyxl.utils import get_column_letter
from openpyxl.utils.dataframe import dataframe_to_rows

import config
from drift_detector import CATEGORY_LABELS, per_server_summary

logger = logging.getLogger(__name__)

# ── Colour palette ─────────────────────────────────────────────────────────
CLR = {
    "header_bg":   "1F3864",   # Dark navy
    "header_fg":   "FFFFFF",
    "drift_bg":    "FFCCCC",   # Light red
    "drift_fg":    "8B0000",   # Dark red
    "pass_bg":     "CCFFCC",   # Light green
    "error_bg":    "FFFFCC",   # Light yellow
    "alt_row":     "F2F2F2",   # Alternating row grey
    "tab_drift":   "FF4C4C",
    "tab_summary": "2E75B6",
    "tab_detail":  "548235",
}

# ── Display column names & widths for the Drift Details sheet ──────────────
DRIFT_DISPLAY: list[tuple[str, str, int]] = [
    # (df_column,        header,                  width)
    ("server_name",      "Server",                22),
    ("database_name",    "Database",              22),
    ("category_label",   "Check Category",        28),
    ("check_item",       "Check Item",            38),
    ("current_value",    "Current Value",         20),
    ("target_value",     "Target Value",          18),
    ("cis_control",      "CIS Control",           32),
    ("remediation",      "Remediation Script",    60),
]

# ── Display columns for the Summary sheet ──────────────────────────────────
SUMMARY_DISPLAY: list[tuple[str, int]] = [
    ("Server",   28),
    ("PASS",     10),
    ("DRIFT",    10),
    ("ERROR",    10),
    ("SKIPPED",  10),
    ("TOTAL",    10),
]


# ── Utility helpers ────────────────────────────────────────────────────────

def _header_font(bold: bool = True, fg: str = CLR["header_fg"]) -> Font:
    return Font(name="Calibri", bold=bold, color=fg, size=11)


def _cell_font(bold: bool = False, color: str = "000000") -> Font:
    return Font(name="Calibri", bold=bold, color=color, size=10)


def _fill(hex_color: str) -> PatternFill:
    return PatternFill("solid", fgColor=hex_color)


def _thin_border() -> Border:
    s = Side(style="thin", color="D3D3D3")
    return Border(left=s, right=s, top=s, bottom=s)


def _write_header_row(ws, headers: list[str]) -> None:
    ws.append(headers)
    for cell in ws[ws.max_row]:
        cell.font      = _header_font()
        cell.fill      = _fill(CLR["header_bg"])
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border    = _thin_border()
    ws.row_dimensions[ws.max_row].height = 30


def _set_column_widths(ws, widths: list[int]) -> None:
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


def _freeze_and_autofilter(ws, freeze_cell: str = "A2") -> None:
    ws.freeze_panes = freeze_cell
    ws.auto_filter.ref = ws.dimensions


# ── Cover / Meta sheet ─────────────────────────────────────────────────────

def _build_cover_sheet(wb: Workbook, run_summary: dict, run_id: str,
                        generated_at: str) -> None:
    ws = wb.active
    ws.title = "📋 Cover"
    ws.sheet_view.showGridLines = False

    title_fill = _fill(CLR["header_bg"])
    title_font = Font(name="Calibri", bold=True, color="FFFFFF", size=18)

    # Title block
    ws.merge_cells("B2:G2")
    ws["B2"] = "SQL Server Configuration Drift Detection Report"
    ws["B2"].font      = title_font
    ws["B2"].fill      = title_fill
    ws["B2"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 40

    ws.merge_cells("B3:G3")
    ws["B3"] = "CIS Benchmark Compliance-as-Code  |  Confidential"
    ws["B3"].font      = Font(name="Calibri", italic=True, color="FFFFFF", size=11)
    ws["B3"].fill      = title_fill
    ws["B3"].alignment = Alignment(horizontal="center")
    ws.row_dimensions[3].height = 22

    # Meta rows
    meta_rows = [
        ("Generated At",   generated_at),
        ("Run ID",         run_id),
        ("Total Checks",   str(run_summary["total"])),
        ("✅ PASS",        str(run_summary["pass"])),
        ("🔴 DRIFT",       str(run_summary["drift"])),
        ("⚠️ ERROR",       str(run_summary["error"])),
        ("⏭️ SKIPPED",    str(run_summary["skipped"])),
    ]
    for i, (label, value) in enumerate(meta_rows, start=5):
        ws.cell(row=i, column=2, value=label).font  = Font(bold=True, size=11)
        ws.cell(row=i, column=3, value=value).font  = Font(size=11)
        ws.row_dimensions[i].height = 18

    ws.column_dimensions["B"].width = 20
    ws.column_dimensions["C"].width = 45


# ── Executive Summary sheet ────────────────────────────────────────────────

def _build_summary_sheet(wb: Workbook, summary_df: pd.DataFrame) -> None:
    ws = wb.create_sheet("📊 Executive Summary")
    ws.sheet_view.showGridLines = False

    _write_header_row(ws, [col for col, _ in SUMMARY_DISPLAY])
    _set_column_widths(ws, [w for _, w in SUMMARY_DISPLAY])

    for r_idx, row in enumerate(summary_df.itertuples(index=False), start=2):
        values = [getattr(row, col, "") for col, _ in SUMMARY_DISPLAY]
        ws.append(values)
        drift_count = getattr(row, "DRIFT", 0)
        fill_color  = CLR["drift_bg"] if drift_count > 0 else CLR["pass_bg"]
        for c_idx, cell in enumerate(ws[ws.max_row], start=1):
            cell.fill      = _fill(fill_color)
            cell.font      = _cell_font()
            cell.border    = _thin_border()
            cell.alignment = Alignment(horizontal="center")
        # Server name left-aligned
        ws.cell(row=ws.max_row, column=1).alignment = Alignment(horizontal="left")

    ws.freeze_panes = "A2"
    ws.sheet_properties.tabColor = CLR["tab_summary"]


# ── Drift Details sheet ────────────────────────────────────────────────────

def _build_drift_sheet(wb: Workbook, drift_df: pd.DataFrame) -> None:
    ws = wb.create_sheet("🔴 Drift Details")
    ws.sheet_view.showGridLines = False

    if drift_df.empty:
        ws["A1"] = "✅  No drift detected in this run."
        ws["A1"].font = Font(bold=True, color="006400", size=14)
        ws.sheet_properties.tabColor = "006400"
        return

    headers = [header for _, header, _ in DRIFT_DISPLAY]
    widths   = [width  for _, _,      width in DRIFT_DISPLAY]
    _write_header_row(ws, headers)
    _set_column_widths(ws, widths)

    prev_server = None
    for r_idx, row in enumerate(drift_df.itertuples(index=False), start=2):
        values = [getattr(row, col, "") for col, _, _ in DRIFT_DISPLAY]
        ws.append(values)
        current_server = values[0]
        alt = current_server != prev_server
        prev_server    = current_server

        for c_idx, cell in enumerate(ws[ws.max_row], start=1):
            cell.fill      = _fill(CLR["drift_bg"])
            cell.font      = _cell_font(color=CLR["drift_fg"])
            cell.border    = _thin_border()
            cell.alignment = Alignment(
                wrap_text=True,
                vertical="top",
                horizontal="left" if c_idx not in (5, 6) else "center",
            )
        ws.row_dimensions[ws.max_row].height = 40

    _freeze_and_autofilter(ws)
    ws.sheet_properties.tabColor = CLR["tab_drift"]


# ── Per-category detail sheets ─────────────────────────────────────────────

def _build_category_sheets(wb: Workbook, drift_df: pd.DataFrame) -> None:
    """One sheet per drift category for easy filtering."""
    if drift_df.empty:
        return
    for cat_key, cat_label in CATEGORY_LABELS.items():
        cat_df = drift_df[drift_df["check_category"] == cat_key].copy()
        if cat_df.empty:
            continue

        safe_title = cat_label[:28]   # sheet name ≤ 31 chars
        ws = wb.create_sheet(f"  {safe_title}")
        ws.sheet_view.showGridLines = False

        headers = [header for _, header, _ in DRIFT_DISPLAY]
        widths   = [width  for _, _,      width in DRIFT_DISPLAY]
        _write_header_row(ws, headers)
        _set_column_widths(ws, widths)

        for r_idx, row in enumerate(cat_df.itertuples(index=False), start=2):
            values = [getattr(row, col, "") for col, _, _ in DRIFT_DISPLAY]
            ws.append(values)
            fill = CLR["alt_row"] if r_idx % 2 == 0 else "FFFFFF"
            for c_idx, cell in enumerate(ws[ws.max_row], start=1):
                cell.fill      = _fill(fill)
                cell.font      = _cell_font()
                cell.border    = _thin_border()
                cell.alignment = Alignment(wrap_text=True, vertical="top")
            ws.row_dimensions[ws.max_row].height = 36

        _freeze_and_autofilter(ws)
        ws.sheet_properties.tabColor = CLR["tab_detail"]


# ── Public entry point ─────────────────────────────────────────────────────

def generate_report(
    drift_df: pd.DataFrame,
    summary_df: pd.DataFrame,
    run_summary: dict,
    run_id: str,
) -> Path | None:
    """
    Builds the Excel workbook and saves it to REPORTS_DIR.
    Returns the Path of the saved file, or None if no drifts were found.
    """
    drift_count = run_summary.get("drift", 0)
    if drift_count == 0 and not config.DRY_RUN:
        logger.info("No drifts detected – skipping Excel report generation.")
        return None

    ts_str = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%SZ")
    generated_at = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    filename = config.REPORTS_DIR / f"DriftReport_{ts_str}.xlsx"

    wb = Workbook()

    _build_cover_sheet(wb, run_summary, run_id, generated_at)
    _build_summary_sheet(wb, summary_df)
    _build_drift_sheet(wb, drift_df)
    _build_category_sheets(wb, drift_df)

    wb.save(filename)
    logger.info("Excel report saved → %s", filename)
    return filename
