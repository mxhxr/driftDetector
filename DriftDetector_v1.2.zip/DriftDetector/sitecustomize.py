"""
sitecustomize.py  —  Loaded automatically by the embedded Python runtime.
Adds the local Lib\site-packages to sys.path so pip-installed packages
are found without needing a full Python installation.
"""
import sys, os
_here = os.path.dirname(os.path.abspath(__file__))
_site = os.path.join(_here, "Lib", "site-packages")
if os.path.isdir(_site) and _site not in sys.path:
    sys.path.insert(0, _site)
