# ================================================================
#  schedule_task.ps1  —  Register DriftDetector Scheduled Task
#  Run as Administrator:
#    powershell -ExecutionPolicy Bypass -File schedule_task.ps1
# ================================================================
#Requires -RunAsAdministrator
param(
    [string]$RunAs       = '',
    [string]$Password    = '',
    [string]$TriggerTime = '06:00',
    [switch]$Remove
)

$ROOT      = $PSScriptRoot
$TASK_NAME = 'DriftDetector - SQL CIS Audit'

# Prefer portable Python, fall back to system
$PYEXE = Join-Path $ROOT 'python\python.exe'
if (-not (Test-Path $PYEXE)) {
    $PYEXE = (Get-Command python -ErrorAction SilentlyContinue)?.Source
    if (-not $PYEXE) {
        Write-Error "Python not found. Run bootstrap.bat first."; exit 1
    }
}
$SCRIPT = Join-Path $ROOT 'main.py'

if ($Remove) {
    Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false -ErrorAction SilentlyContinue
    Write-Host "[OK] Task '$TASK_NAME' removed." -ForegroundColor Green
    exit 0
}

$action  = New-ScheduledTaskAction -Execute $PYEXE -Argument "`"$SCRIPT`"" -WorkingDirectory $ROOT
$trigger = New-ScheduledTaskTrigger -Daily -At $TriggerTime
$princ   = if ($RunAs) {
    New-ScheduledTaskPrincipal -UserId $RunAs -LogonType Password -RunLevel Highest
} else {
    New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
}
$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Hours 2) `
    -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 15) `
    -StartWhenAvailable -MultipleInstances IgnoreNew

$params = @{ TaskName=$TASK_NAME; Action=$action; Trigger=$trigger;
             Principal=$princ; Settings=$settings; Force=$true;
             Description='SQL Server CIS Benchmark drift detection. Exit 0=clean, 2=drift, 1=error.' }
if ($RunAs -and $Password) { $params['Password'] = $Password }

Register-ScheduledTask @params | Out-Null

Write-Host ""
Write-Host "[OK] '$TASK_NAME' registered — runs daily at $TriggerTime" -ForegroundColor Green
Write-Host "     Python: $PYEXE" -ForegroundColor Gray
Write-Host "     Script: $SCRIPT" -ForegroundColor Gray
Write-Host ""
Write-Host "Useful commands:" -ForegroundColor Cyan
Write-Host "  Run now : Start-ScheduledTask -TaskName '$TASK_NAME'"
Write-Host "  Status  : Get-ScheduledTask  -TaskName '$TASK_NAME' | Get-ScheduledTaskInfo"
Write-Host "  Remove  : .\schedule_task.ps1 -Remove"
