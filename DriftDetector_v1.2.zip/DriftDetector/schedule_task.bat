@echo off
:: ================================================================
::  schedule_task.bat  —  Register Windows Scheduled Task
::  Must be run as Administrator.
::  Schedules DriftDetector to run daily at 06:00.
::  Automatically uses portable Python if present.
:: ================================================================
setlocal
set ROOT=%~dp0

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [ERR] Run as Administrator.
    echo        Right-click schedule_task.bat ^> Run as administrator
    echo.
    pause & exit /b 1
)

:: Resolve Python executable
set PYEXE=%ROOT%python\python.exe
if not exist "%PYEXE%" (
    where python >nul 2>&1
    if %errorlevel%==0 ( set PYEXE=python ) else (
        echo  [ERR] Python not found. Run bootstrap.bat first.
        pause & exit /b 1
    )
)

set TASK_NAME=DriftDetector - SQL CIS Audit
set SCRIPT_PATH=%ROOT%main.py
:: Remove trailing backslash
if "%ROOT:~-1%"=="\" set ROOT=%ROOT:~0,-1%

echo.
echo  =========================================
echo   DriftDetector — Task Scheduler Setup
echo  =========================================
echo   Task    : %TASK_NAME%
echo   Python  : %PYEXE%
echo   Script  : %SCRIPT_PATH%
echo   Schedule: Daily at 06:00
echo.

set /p RUN_AS="  Run as account (blank = SYSTEM): "
if "%RUN_AS%"=="" (
    set LOGON_TYPE=/ru SYSTEM
) else (
    set /p RUN_PWD="  Password for %RUN_AS%: "
    set LOGON_TYPE=/ru "%RUN_AS%" /rp "%RUN_PWD%"
)

schtasks /create ^
  /tn "%TASK_NAME%" ^
  /tr "\"%PYEXE%\" \"%SCRIPT_PATH%\"" ^
  /sc DAILY /st 06:00 ^
  %LOGON_TYPE% /rl HIGHEST /f /it

if %errorlevel%==0 (
    echo.
    echo  [OK]  Task registered. Open Task Scheduler to set "Start in": %ROOT%
    echo.
    echo  IMPORTANT: In Task Scheduler ^> right-click the task ^> Properties
    echo             ^> Actions ^> Edit ^> set "Start in (optional)" to:
    echo             %ROOT%
) else (
    echo.
    echo  [ERR] schtasks failed. Try: powershell -File schedule_task.ps1
)
echo.
pause
