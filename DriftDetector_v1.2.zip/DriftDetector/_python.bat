@echo off
:: ================================================================
::  _python.bat  —  Internal helper: resolves which Python to use.
::  Called by other .bat files via:  call "%~dp0_python.bat"
::  Sets %PYEXE% to the correct python.exe path.
:: ================================================================
set PYEXE=%~dp0python\python.exe

if exist "%PYEXE%" (
    :: Use the bundled portable runtime
    exit /b 0
)

:: Fallback: try system Python
where python >nul 2>&1
if %errorlevel%==0 (
    set PYEXE=python
    exit /b 0
)

:: Neither found
echo.
echo  [ERR] Python not found.
echo.
echo  Option A (recommended — no install required):
echo    Double-click  bootstrap.bat  to download a portable runtime.
echo.
echo  Option B (system-wide install):
echo    Install Python 3.12+ from https://python.org/downloads/
echo    Check "Add python.exe to PATH" during install.
echo.
exit /b 1
