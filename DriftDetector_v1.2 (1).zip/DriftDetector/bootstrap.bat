@echo off
:: ================================================================
::  bootstrap.bat  --  DriftDetector One-Time Setup
::  Downloads portable Python + all packages into this folder.
::  No admin rights. No system-wide install.
::  Run ONCE, then use open_ui_with_api.bat forever after.
:: ================================================================
@setlocal EnableDelayedExpansion
set ROOT=%~dp0
set PYDIR=%ROOT%python
set PYEXE=%PYDIR%\python.exe

title DriftDetector Bootstrap Setup

echo.
echo  ================================================================
echo   DriftDetector -- Portable Bootstrap Setup
echo  ================================================================
echo   Downloads Python + packages into: %PYDIR%
echo   Nothing installed system-wide. Estimated: ~35 MB (once only)
echo  ================================================================
echo.

:: ---- Already bootstrapped? -------------------------------------------
if exist "%PYEXE%" (
    echo  [OK]  Embedded Python already present.
    goto CHECK_PACKAGES
)

:: ---- Download Python embeddable zip ----------------------------------
echo  [1/4] Downloading Python 3.12 embeddable runtime (~12 MB)...
set PY_URL=https://www.python.org/ftp/python/3.12.9/python-3.12.9-embed-amd64.zip
set PY_ZIP=%TEMP%\py_embed.zip

powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%PY_URL%' -OutFile '%PY_ZIP%' -UseBasicParsing"

if not exist "%PY_ZIP%" (
    echo.
    echo  [ERR] Download failed. Check your internet connection.
    echo.
    echo  Manual fallback:
    echo    1. Download: %PY_URL%
    echo    2. Create a "python" folder here
    echo    3. Extract the zip into it
    echo    4. Run bootstrap.bat again
    echo.
    pause
    exit /b 1
)
echo  [OK]  Downloaded.

:: ---- Extract Python --------------------------------------------------
echo  [2/4] Extracting Python runtime...
if not exist "%PYDIR%" mkdir "%PYDIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%PY_ZIP%' -DestinationPath '%PYDIR%' -Force"
del /f /q "%PY_ZIP%" 2>nul

if not exist "%PYEXE%" (
    echo  [ERR] Extraction failed -- python.exe missing after unzip.
    pause
    exit /b 1
)
echo  [OK]  Extracted to python\

:: ---- Copy sitecustomize.py into runtime ------------------------------
if exist "%ROOT%sitecustomize.py" (
    copy /y "%ROOT%sitecustomize.py" "%PYDIR%\sitecustomize.py" >nul
    echo  [OK]  sitecustomize.py copied.
)

:: ---- Uncomment "import site" in the ._pth file ----------------------
::  The embeddable zip ships with "#import site" disabled by default.
::  Enabling it lets Python find pip-installed packages.
echo  [3/4] Enabling site-packages support...

set PTH_FILE=
for %%f in ("%PYDIR%\python*._pth") do set PTH_FILE=%%f

if defined PTH_FILE (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='%PTH_FILE%'; $c=Get-Content $p -Raw; $c=$c -replace '#import site','import site'; Set-Content $p $c -NoNewline"
    echo  [OK]  site-packages enabled.
) else (
    echo  [!!]  ._pth file not found -- packages may not load. Re-run bootstrap.bat.
)

:: ---- Bootstrap pip ---------------------------------------------------
echo  [4/4] Installing packages (pyodbc, pandas, openpyxl, flask, flask-cors ~22 MB)...
set GETPIP=%TEMP%\get-pip.py
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://bootstrap.pypa.io/get-pip.py' -OutFile '%GETPIP%' -UseBasicParsing"

if not exist "%GETPIP%" (
    echo  [ERR] Could not download get-pip.py. Check internet and retry.
    pause
    exit /b 1
)
"%PYEXE%" "%GETPIP%" --quiet --no-warn-script-location
del /f /q "%GETPIP%" 2>nul

:: ---- Install packages -----------------------------------------------
:CHECK_PACKAGES
"%PYEXE%" -m pip install pyodbc pandas openpyxl flask flask-cors --target="%PYDIR%\Lib\site-packages" --quiet --no-warn-script-location --disable-pip-version-check

if %errorlevel% neq 0 (
    echo.
    echo  [!!]  pip install failed. Check internet and run bootstrap.bat again.
    echo.
    pause
    exit /b 1
)
echo  [OK]  All packages installed.

:: ---- Verify ----------------------------------------------------------
echo.
echo  Verifying...
"%PYEXE%" -c "import pyodbc, pandas, openpyxl, flask, flask_cors; print('  [OK]  All packages verified.')"
if %errorlevel% neq 0 (
    echo  [!!]  Verification failed. Run bootstrap.bat again.
    pause
    exit /b 1
)

:: ---- Check ODBC driver -----------------------------------------------
echo.
echo  Checking ODBC drivers...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=Get-OdbcDriver | Where-Object{$_.Name -like '*SQL Server*'} | Select-Object -ExpandProperty Name; if($d){$d|ForEach-Object{Write-Host ('  [OK]  Found: '+$_)}}else{Write-Host '  [!!]  No SQL Server ODBC driver found.' -ForegroundColor Yellow; Write-Host '        Download: https://aka.ms/downloadmsodbcsql' -ForegroundColor Gray}"

:: ---- Create settings.env if missing ---------------------------------
if not exist "%ROOT%settings.env" (
    (
        echo # DriftDetector Runtime Settings
        echo DRIFT_REPO_SERVER=
        echo DRIFT_REPO_DB=DriftDetector
        echo DRIFT_TRUSTED=1
        echo DRIFT_SQL_USER=
        echo DRIFT_SQL_PWD=
        echo DRIFT_ODBC_DRIVER=ODBC Driver 17 for SQL Server
        echo DRIFT_CONN_TIMEOUT=30
        echo DRIFT_LOG_LEVEL=INFO
    ) > "%ROOT%settings.env"
    echo  [OK]  Created settings.env
)

:: ---- Create output folders -------------------------------------------
if not exist "%ROOT%reports" mkdir "%ROOT%reports"
if not exist "%ROOT%logs"    mkdir "%ROOT%logs"
if not exist "%ROOT%data"    mkdir "%ROOT%data"

:: ---- Done ------------------------------------------------------------
echo.
echo  ================================================================
echo   Bootstrap complete!
echo  ================================================================
echo.
echo   Next steps:
echo.
echo   1. Edit settings.env -- set DRIFT_REPO_SERVER to your SQL Server.
echo.
echo   2. Deploy the schema (run once in SSMS):
echo      Open .internal\schema.sql and execute it.
echo.
echo   3. Double-click open_ui_with_api.bat to launch the dashboard.
echo.
echo   Portability: copy this entire folder to any Windows x64 machine.
echo   No re-download needed as long as python\ is included.
echo.
pause
