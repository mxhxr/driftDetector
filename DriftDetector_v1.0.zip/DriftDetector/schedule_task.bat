@echo off
:: ============================================================
::  schedule_task.bat  —  Register Windows Scheduled Task
::  Must be run as Administrator.
::  Schedules DriftDetector to run daily at 06:00.
:: ============================================================
setlocal

:: Verify admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [ERR] This script must be run as Administrator.
    echo        Right-click schedule_task.bat ^> Run as administrator
    echo.
    pause
    exit /b 1
)

set TASK_NAME=DriftDetector - SQL CIS Audit
set PYTHON_EXE=python.exe
set SCRIPT_PATH=%~dp0main.py
set WORKING_DIR=%~dp0
:: Remove trailing backslash from working dir
if "%WORKING_DIR:~-1%"=="\" set WORKING_DIR=%WORKING_DIR:~0,-1%

echo.
echo  =========================================
echo   DriftDetector — Task Scheduler Setup
echo  =========================================
echo.
echo  Task name   : %TASK_NAME%
echo  Script      : %SCRIPT_PATH%
echo  Working dir : %WORKING_DIR%
echo  Schedule    : Daily at 06:00
echo.

set /p RUN_AS="  Run as which account? (leave blank for SYSTEM): "
if "%RUN_AS%"=="" (
    set RUN_AS=SYSTEM
    set LOGON_TYPE=/ru SYSTEM
) else (
    set /p RUN_PWD="  Password for %RUN_AS%: "
    set LOGON_TYPE=/ru "%RUN_AS%" /rp "%RUN_PWD%"
)

echo.
echo  Creating scheduled task...

schtasks /create ^
  /tn "%TASK_NAME%" ^
  /tr "\"%PYTHON_EXE%\" \"%SCRIPT_PATH%\"" ^
  /sc DAILY ^
  /st 06:00 ^
  /sd %date:~10,4%-%date:~4,2%-%date:~7,2% ^
  %LOGON_TYPE% ^
  /rl HIGHEST ^
  /f ^
  /it

if %errorlevel%==0 (
    echo.
    echo  [OK]  Task "%TASK_NAME%" registered successfully.
    echo.
    echo  To verify: open Task Scheduler ^(taskschd.msc^) and look under
    echo  Task Scheduler Library for "%TASK_NAME%"
    echo.
    echo  To change the working directory ^(required for relative paths^):
    echo  Task Scheduler ^> right-click task ^> Properties ^> Actions ^> Edit
    echo  Set "Start in" to: %WORKING_DIR%
    echo.
    echo  Alternatively, run the PowerShell version for full control:
    echo    powershell -ExecutionPolicy Bypass -File schedule_task.ps1
) else (
    echo.
    echo  [ERR] schtasks failed. Try the PowerShell version instead:
    echo        powershell -ExecutionPolicy Bypass -File schedule_task.ps1
)

echo.
pause
