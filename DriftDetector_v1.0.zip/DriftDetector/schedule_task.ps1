# ================================================================
#  schedule_task.ps1  —  DriftDetector Task Scheduler Registration
#  Provides more control than the .bat version.
#  Run as Administrator:
#    powershell -ExecutionPolicy Bypass -File schedule_task.ps1
# ================================================================
#Requires -RunAsAdministrator
param(
    [string]$RunAs       = '',
    [string]$Password    = '',
    [string]$TriggerTime = '06:00',
    [switch]$Remove
)

$ROOT      = $PSScriptRoot
$TASK_NAME = 'DriftDetector - SQL CIS Audit'
$PYTHON    = (Get-Command python -ErrorAction SilentlyContinue)?.Source ?? 'python.exe'
$SCRIPT    = Join-Path $ROOT 'main.py'

if ($Remove) {
    Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false -ErrorAction SilentlyContinue
    Write-Host "[OK] Task '$TASK_NAME' removed." -ForegroundColor Green
    exit 0
}

# Action
$action = New-ScheduledTaskAction `
    -Execute    $PYTHON `
    -Argument   "`"$SCRIPT`"" `
    -WorkingDirectory $ROOT

# Daily trigger
$trigger = New-ScheduledTaskTrigger -Daily -At $TriggerTime

# Principal
if ($RunAs) {
    $principal = New-ScheduledTaskPrincipal -UserId $RunAs -LogonType Password -RunLevel Highest
} else {
    $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
}

# Settings
$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit      (New-TimeSpan -Hours 2) `
    -RestartCount            3 `
    -RestartInterval         (New-TimeSpan -Minutes 15) `
    -StartWhenAvailable      `
    -MultipleInstances       IgnoreNew `
    -WakeToRun:$false

$params = @{
    TaskName  = $TASK_NAME
    Action    = $action
    Trigger   = $trigger
    Principal = $principal
    Settings  = $settings
    Force     = $true
    Description = 'SQL Server CIS Benchmark configuration drift detection. Exit 0=clean, 2=drift, 1=error.'
}
if ($RunAs -and $Password) { $params['Password'] = $Password }

Register-ScheduledTask @params | Out-Null

Write-Host ""
Write-Host "[OK] Scheduled task '$TASK_NAME' registered." -ForegroundColor Green
Write-Host "     Runs daily at $TriggerTime as $(if($RunAs){$RunAs}else{'SYSTEM'})" -ForegroundColor Gray
Write-Host ""
Write-Host "Useful commands:" -ForegroundColor Cyan
Write-Host "  Run now  : Start-ScheduledTask  -TaskName '$TASK_NAME'"
Write-Host "  Status   : Get-ScheduledTask    -TaskName '$TASK_NAME' | Get-ScheduledTaskInfo"
Write-Host "  Remove   : .\schedule_task.ps1 -Remove"
Write-Host ""
