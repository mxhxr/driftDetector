@echo off
:: ============================================================
::  run_audit.bat  —  DriftDetector Production Run
::  Double-click to execute a full live audit.
::  Exit code 0=clean  2=drift found  1=fatal error
:: ============================================================
setlocal

:: Load settings.env if it exists
if exist "%~dp0settings.env" (
    for /f "usebackq tokens=1,* delims==" %%A in ("%~dp0settings.env") do (
        if not "%%A"=="" if not "%%A:~0,1%"=="#" set "%%A=%%B"
    )
)

cd /d "%~dp0"
title DriftDetector — Running Audit...

echo.
echo  =========================================
echo   DriftDetector — SQL Server CIS Audit
echo  =========================================
echo   Mode  : LIVE (results written to DB)
echo   Time  : %date% %time%
echo  =========================================
echo.

python main.py %*

set EXIT_CODE=%errorlevel%

echo.
if %EXIT_CODE%==0 (
    echo  [OK]  All checks passed. No drift detected.
) else if %EXIT_CODE%==2 (
    echo  [!!]  Drift detected. Check the reports\ folder for the Excel report.
) else (
    echo  [ERR] Fatal error. Check logs\ for details.
)
echo.
echo  Press any key to close...
pause >nul
exit /b %EXIT_CODE%
