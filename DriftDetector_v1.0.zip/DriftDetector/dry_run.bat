@echo off
:: ============================================================
::  dry_run.bat  —  DriftDetector Safe Test / Dry Run
::  Runs all audit checks but writes NOTHING to the database.
::  Always generates an Excel report in reports\
:: ============================================================
setlocal

if exist "%~dp0settings.env" (
    for /f "usebackq tokens=1,* delims==" %%A in ("%~dp0settings.env") do (
        if not "%%A"=="" if not "%%A:~0,1%"=="#" set "%%A=%%B"
    )
)

cd /d "%~dp0"
title DriftDetector — Dry Run (no DB writes)

echo.
echo  =========================================
echo   DriftDetector — DRY RUN
echo  =========================================
echo   Mode  : DRY RUN (no database writes)
echo   Time  : %date% %time%
echo  =========================================
echo.

python main.py --dry-run %*

set EXIT_CODE=%errorlevel%

echo.
echo  Dry run complete. Report saved to reports\
echo  No data was written to the repository database.
echo.
echo  Press any key to close...
pause >nul
exit /b %EXIT_CODE%
