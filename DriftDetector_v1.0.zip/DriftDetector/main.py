"""
=============================================================
  main.py  —  Configuration Drift Detection Orchestrator
  SQL Server CIS Benchmark Compliance-as-Code
=============================================================

Usage
-----
  python main.py                       Normal run
  python main.py --dry-run             Audit only; no DB writes
  python main.py --servers SRV1 SRV2  Override server list
  python main.py --fail-fast           Stop on first connection error
  python main.py --log-level DEBUG     Verbose output
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pyodbc

# ── Load settings.env before importing config ──────────────────────────────
_ROOT = Path(__file__).parent.resolve()
_ENV  = _ROOT / "settings.env"
if _ENV.exists():
    with open(_ENV, encoding="utf-8") as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _, _v = _line.partition("=")
                os.environ.setdefault(_k.strip(), _v.strip())

import config
from audit_checks import audit_server
from db_manager import (
    AuditResult,
    get_audit_conn,
    load_baselines,
    persist_results,
)
from drift_detector import (
    extract_drifts,
    per_server_summary,
    results_to_dataframe,
    summarise_run,
)
from reporter import generate_report


# ── Logging ────────────────────────────────────────────────────────────────
def _setup_logging(level: str) -> None:
    fmt      = "%(asctime)s [%(levelname)-8s] %(name)s — %(message)s"
    date_fmt = "%Y-%m-%d %H:%M:%S"
    log_file = config.LOGS_DIR / f"drift_run_{datetime.now().strftime('%Y%m%d')}.log"
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format=fmt,
        datefmt=date_fmt,
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_file, encoding="utf-8"),
        ],
    )


logger = logging.getLogger("main")


# ── CLI ────────────────────────────────────────────────────────────────────
def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="SQL Server Configuration Drift Detector — CIS Benchmark",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--dry-run",   action="store_true", default=False)
    p.add_argument("--fail-fast", action="store_true", default=False)
    p.add_argument("--servers", nargs="+", metavar="SERVER")
    p.add_argument("--log-level", default=config.LOG_LEVEL,
                   choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return p.parse_args()


# ── Preflight check ────────────────────────────────────────────────────────
def _preflight() -> list[str]:
    """Return a list of configuration problems found before the run starts."""
    problems = []
    if not config.REPO_DB.get("server"):
        problems.append(
            "DRIFT_REPO_SERVER is not set. "
            "Run setup.ps1 or add it to settings.env."
        )
    return problems


# ── Banner ─────────────────────────────────────────────────────────────────
def _banner(run_id: str, dry_run: bool) -> None:
    w = 66
    logger.info("=" * w)
    logger.info("  SQL Server Configuration Drift Detection")
    logger.info("  CIS Benchmark Compliance-as-Code — v1.0")
    logger.info("-" * w)
    logger.info("  Run ID  : %s", run_id)
    logger.info("  Started : %s UTC",
                datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S"))
    logger.info("  Root    : %s", config.ROOT)
    if dry_run:
        logger.info("  *** DRY-RUN MODE — no writes to repository DB ***")
    logger.info("=" * w)


# ── Single-server wrapper ──────────────────────────────────────────────────
def _audit_one(srv_cfg: dict, run_id: uuid.UUID) -> list[AuditResult]:
    server = srv_cfg["server"]
    logger.info("── Auditing server: %s", server)
    try:
        with get_audit_conn(server) as conn:
            return audit_server(conn, server, run_id)
    except pyodbc.Error as exc:
        logger.error("  ✗ Cannot connect to [%s]: %s", server, exc)
        return [AuditResult(
            run_id=run_id, server_name=server, database_name=None,
            check_category="CONNECTION", check_item="connectivity",
            current_value=None, target_value=None,
            status="ERROR", error_message=str(exc),
        )]


# ── Main ───────────────────────────────────────────────────────────────────
def main() -> int:
    args      = _parse_args()
    dry_run   = args.dry_run   or config.DRY_RUN
    fail_fast = args.fail_fast or config.FAIL_FAST
    config.DRY_RUN   = dry_run
    config.FAIL_FAST = fail_fast

    _setup_logging(args.log_level)

    run_id  = uuid.uuid4()
    run_str = str(run_id)
    _banner(run_str, dry_run)

    # Preflight
    problems = _preflight()
    if problems:
        for p in problems:
            logger.critical("CONFIG: %s", p)
        logger.critical(
            "Fix the above issues (run setup.ps1 or edit settings.env), then retry."
        )
        return 1

    # Load baselines
    try:
        baselines = load_baselines()
    except Exception as exc:
        logger.critical("Cannot load baselines from repository: %s", exc)
        return 1

    if not baselines:
        logger.critical("No active baselines in CIS_Baselines. Did schema.sql run?")
        return 1

    # Server list
    servers: list[dict] = (
        [{"server": s} for s in args.servers]
        if args.servers else config.TARGET_SERVERS
    )
    if not servers:
        logger.error(
            "No target servers configured. "
            "Add them in the UI (Target Servers panel) or edit config.py."
        )
        return 1

    logger.info("Auditing %d server(s) …", len(servers))

    # Run audits
    all_results: list[AuditResult] = []
    for srv in servers:
        results = _audit_one(srv, run_id)
        all_results.extend(results)
        has_conn_err = any(r.check_category == "CONNECTION" for r in results)
        if has_conn_err and fail_fast:
            logger.warning("--fail-fast: aborting after connection error.")
            break

    # DataFrames
    full_df    = results_to_dataframe(all_results, baselines)
    drift_df   = extract_drifts(full_df)
    summary_df = per_server_summary(full_df)
    run_stats  = summarise_run(full_df)

    logger.info("─" * 66)
    logger.info(
        "Summary → Total: %d | PASS: %d | DRIFT: %d | ERROR: %d | SKIPPED: %d",
        run_stats["total"], run_stats["pass"],
        run_stats["drift"], run_stats["error"], run_stats["skipped"],
    )
    if not drift_df.empty:
        for srv, grp in drift_df.groupby("server_name"):
            logger.warning("  [%s] → %d drift(s)", srv, len(grp))

    # Persist
    try:
        persist_results(all_results, dry_run=dry_run)
    except Exception as exc:
        logger.error("Failed to persist results: %s", exc)

    # Report
    try:
        report_path = generate_report(drift_df, summary_df, run_stats, run_str)
        if report_path:
            logger.info("Report → %s", report_path)
        else:
            logger.info("All checks PASSED — no Excel report generated.")
    except Exception as exc:
        logger.error("Failed to generate report: %s", exc)

    logger.info("=" * 66)
    logger.info("Run complete.")

    return 0 if (run_stats["drift"] == 0 and run_stats["error"] == 0) else 2


if __name__ == "__main__":
    sys.exit(main())
