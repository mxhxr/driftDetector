@echo off
:: ============================================================
::  open_ui.bat  —  Open DriftDetector Dashboard
:: ============================================================
start "" "%~dp0drift_detector_ui.html"
