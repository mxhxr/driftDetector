@echo off
:: ============================================================
::  open_ui_with_api.bat  —  DriftDetector Full Launch
::  Starts the local API server, then opens the UI in your
::  default browser. Close the API window to shut down.
:: ============================================================
setlocal

:: Load settings.env
if exist "%~dp0settings.env" (
    for /f "usebackq tokens=1,* delims==" %%A in ("%~dp0settings.env") do (
        if not "%%A"=="" if not "%%A:~0,1%"=="#" set "%%A=%%B"
    )
)

cd /d "%~dp0"

:: Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [ERR] Python not found in PATH.
    echo        Run setup.ps1 first to install dependencies.
    echo.
    pause
    exit /b 1
)

:: Check api.py exists
if not exist "%~dp0api.py" (
    echo  [ERR] api.py not found in %~dp0
    pause
    exit /b 1
)

echo.
echo  =========================================
echo   DriftDetector — Starting API Server
echo  =========================================
echo.
echo  The API server will open in a separate window.
echo  Keep that window open while using the UI.
echo.

:: Start the API server in a separate, visible window
start "DriftDetector API Server — http://127.0.0.1:5050" ^
  cmd /k "cd /d %~dp0 && python api.py"

:: Wait for API to be ready (up to 8 seconds)
echo  Waiting for API to start...
set /a ATTEMPTS=0
:WAIT_LOOP
timeout /t 1 /nobreak >nul
set /a ATTEMPTS+=1
python -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:5050/api/health', timeout=1)" >nul 2>&1
if %errorlevel%==0 goto API_READY
if %ATTEMPTS% LSS 8 goto WAIT_LOOP

echo  [!!] API did not start in time — opening UI anyway.
echo       Check the API server window for errors.
goto OPEN_UI

:API_READY
echo  [OK] API is online at http://127.0.0.1:5050

:OPEN_UI
echo  Opening dashboard...
start "" "%~dp0drift_detector_ui.html"
echo.
echo  UI opened in your default browser.
echo  Close the "DriftDetector API Server" window to stop the server.
echo.
