@echo off
:: ============================================================
::  open_ui.bat  —  Opens the DriftDetector dashboard
::  The UI requires the API server to be running.
::  Use  open_ui_with_api.bat  to start both together.
:: ============================================================
echo.
echo  Note: For full live functionality, use open_ui_with_api.bat
echo  which starts the API server automatically.
echo.
echo  Opening UI now (API must already be running)...
start "" "%~dp0drift_detector_ui.html"
