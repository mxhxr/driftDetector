@echo off
:: ================================================================
::  bootstrap.bat  --  DriftDetector Air-Gap Bootstrap
::
::  Installs Python and all packages from the vendor\ folder.
::  NO internet access required.
::
::  Run ONCE after unzipping on the target server.
::  Use open_ui_with_api.bat for all subsequent launches.
:: ================================================================
@setlocal EnableDelayedExpansion
set ROOT=%~dp0
set VENDOR=%ROOT%vendor
set PYZIP=%VENDOR%\python-3.12.9-embed-amd64.zip
set GETPIP=%VENDOR%\get-pip.py
set WHEELS=%VENDOR%\wheels
set PYDIR=%ROOT%python
set PYEXE=%PYDIR%\python.exe

title DriftDetector Bootstrap

echo.
echo  ================================================================
echo   DriftDetector -- Air-Gap Bootstrap
echo  ================================================================
echo   Installing from: %VENDOR%
echo   Installing to:   %PYDIR%
echo   No internet access required.
echo  ================================================================
echo.

:: ---- Verify vendor folder is present --------------------------------
if not exist "%VENDOR%" (
    echo  [ERR] vendor\ folder not found at: %VENDOR%
    echo.
    echo  This package was not built with build_portable.bat.
    echo  On an internet-connected machine, run build_portable.bat
    echo  to produce a fully sealed DriftDetector_portable.zip.
    echo.
    pause
    exit /b 1
)

if not exist "%PYZIP%" (
    echo  [ERR] Missing: %PYZIP%
    echo        Run build_portable.bat on an internet-connected machine first.
    pause
    exit /b 1
)

if not exist "%GETPIP%" (
    echo  [ERR] Missing: %GETPIP%
    echo        Run build_portable.bat on an internet-connected machine first.
    pause
    exit /b 1
)

:: Count wheels
set WHEEL_COUNT=0
for %%f in ("%WHEELS%\*.whl") do set /a WHEEL_COUNT+=1
if %WHEEL_COUNT%==0 (
    echo  [ERR] No .whl files found in: %WHEELS%
    echo        Run build_portable.bat on an internet-connected machine first.
    pause
    exit /b 1
)
echo  [OK]  vendor\ present: %WHEEL_COUNT% wheel files found.

:: ---- Skip Python install if already done ----------------------------
if exist "%PYEXE%" (
    echo  [OK]  Portable Python already installed -- skipping extraction.
    goto CHECK_PACKAGES
)

:: ---- Extract Python embeddable --------------------------------------
echo.
echo  [1/3] Extracting Python runtime from vendor...
if not exist "%PYDIR%" mkdir "%PYDIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%PYZIP%' -DestinationPath '%PYDIR%' -Force"

if not exist "%PYEXE%" (
    echo  [ERR] Extraction failed -- python.exe not found after unzip.
    echo        The vendor\python-3.12.9-embed-amd64.zip may be corrupt.
    echo        Re-run build_portable.bat to re-download it.
    pause
    exit /b 1
)
echo  [OK]  Python extracted to python\

:: ---- Copy sitecustomize.py ------------------------------------------
if exist "%ROOT%sitecustomize.py" (
    copy /y "%ROOT%sitecustomize.py" "%PYDIR%\sitecustomize.py" >nul
    echo  [OK]  sitecustomize.py installed.
)

:: ---- Enable site-packages in ._pth file -----------------------------
echo  [2/3] Configuring Python runtime...

set PTH_FILE=
for %%f in ("%PYDIR%\python*._pth") do set PTH_FILE=%%f

if defined PTH_FILE (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='%PTH_FILE%'; $c=Get-Content $p -Raw; $c=$c -replace '#import site','import site'; Set-Content $p $c -NoNewline"
    echo  [OK]  site-packages enabled in: %PTH_FILE%
) else (
    echo  [!!]  ._pth file not found. Packages may not be importable.
    echo        Try deleting python\ and running bootstrap.bat again.
)

:: ---- Bootstrap pip from local get-pip.py ---------------------------
echo        Installing pip from vendor\get-pip.py (offline)...
"%PYEXE%" "%GETPIP%" --quiet --no-warn-script-location --no-index
if %errorlevel% neq 0 (
    echo  [!!]  pip install returned errors -- continuing anyway.
)

:: ---- Install all wheels from vendor\wheels\ -------------------------
:CHECK_PACKAGES
echo  [3/3] Installing packages from vendor\wheels\ (offline)...
echo.

"%PYEXE%" -m pip install ^
    pyodbc ^
    pandas ^
    openpyxl ^
    flask ^
    flask-cors ^
    --find-links="%WHEELS%" ^
    --no-index ^
    --target="%PYDIR%\Lib\site-packages" ^
    --quiet ^
    --no-warn-script-location ^
    --disable-pip-version-check

if %errorlevel% neq 0 (
    echo.
    echo  [ERR] Package installation failed.
    echo.
    echo  Possible causes:
    echo    - A required .whl file is missing from vendor\wheels\
    echo    - The wheel was built for a different Python version/platform
    echo.
    echo  Fix: re-run build_portable.bat on an internet-connected machine
    echo  to rebuild the vendor\ folder, then re-run bootstrap.bat here.
    echo.
    pause
    exit /b 1
)
echo  [OK]  All packages installed from local wheels.

:: ---- Verify all imports work ----------------------------------------
echo.
echo  Verifying imports...
"%PYEXE%" -c "import pyodbc, pandas, openpyxl, flask, flask_cors; print('  [OK]  All packages verified.')"
if %errorlevel% neq 0 (
    echo.
    echo  [ERR] One or more packages failed to import.
    echo        Re-run build_portable.bat and bootstrap.bat.
    pause
    exit /b 1
)

:: ---- Check for ODBC driver (informational only) ---------------------
echo.
echo  Checking ODBC drivers...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=Get-OdbcDriver | Where-Object{$_.Name -like '*SQL Server*'} | Select-Object -ExpandProperty Name; if($d){$d|ForEach-Object{Write-Host ('  [OK]  Found: '+$_)}}else{Write-Host '  [!!]  No SQL Server ODBC driver found.' -ForegroundColor Yellow; Write-Host '        Contact your DBA or sysadmin to install:' -ForegroundColor Gray; Write-Host '        ODBC Driver 17 for SQL Server (msodbcsql.msi)' -ForegroundColor Gray; Write-Host '        It must be installed by an administrator.' -ForegroundColor Gray}"

:: ---- Create settings.env if not present ----------------------------
if not exist "%ROOT%settings.env" (
    (
        echo # DriftDetector Runtime Settings
        echo # Edit DRIFT_REPO_SERVER before running the first audit.
        echo DRIFT_REPO_SERVER=
        echo DRIFT_REPO_DB=DriftDetector
        echo DRIFT_TRUSTED=1
        echo DRIFT_SQL_USER=
        echo DRIFT_SQL_PWD=
        echo DRIFT_ODBC_DRIVER=ODBC Driver 17 for SQL Server
        echo DRIFT_CONN_TIMEOUT=30
        echo DRIFT_LOG_LEVEL=INFO
    ) > "%ROOT%settings.env"
    echo  [OK]  Created settings.env
)

:: ---- Create output folders ------------------------------------------
if not exist "%ROOT%reports" mkdir "%ROOT%reports"
if not exist "%ROOT%logs"    mkdir "%ROOT%logs"
if not exist "%ROOT%data"    mkdir "%ROOT%data"

:: ---- Done -----------------------------------------------------------
echo.
echo  ================================================================
echo   Bootstrap complete. No internet was used.
echo  ================================================================
echo.
echo   Next steps:
echo.
echo   1. Edit settings.env in this folder.
echo      Set DRIFT_REPO_SERVER to your central SQL Server name.
echo.
echo   2. Deploy the database schema (run once):
echo      Open .internal\schema.sql in SSMS and execute it.
echo      (Your DBA can do this -- it just creates two tables.)
echo.
echo   3. Double-click open_ui_with_api.bat to launch the dashboard.
echo.
pause
