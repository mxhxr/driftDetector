@echo off
:: ================================================================
::  build_portable.bat  --  DriftDetector Portable Package Builder
::
::  Run this ONCE on any internet-connected Windows x64 machine.
::  It downloads Python and all package wheels into vendor\
::  then produces:  DriftDetector_portable.zip
::
::  That zip is fully self-contained and runs on any Windows x64
::  machine with no internet access and no Python installed.
::
::  Requirements on THIS (build) machine:
::    - Internet access
::    - Python 3.x installed  (just to run pip download)
::    - PowerShell 5+
:: ================================================================
@setlocal EnableDelayedExpansion
set ROOT=%~dp0
set VENDOR=%ROOT%vendor
set WHEELS=%VENDOR%\wheels

title DriftDetector -- Building Portable Package

echo.
echo  ================================================================
echo   DriftDetector -- Portable Package Builder
echo  ================================================================
echo   This machine needs: internet + any Python install
echo   Output: DriftDetector_portable.zip (fully self-contained)
echo  ================================================================
echo.

:: ---- Check Python available on this machine -------------------------
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERR] Python not found on this build machine.
    echo        Install any Python 3.x from https://python.org to build.
    echo        (It does NOT need to be on the target server.)
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('python --version 2^>^&1') do echo  [OK]  Build Python: %%v

:: ---- Create vendor directories --------------------------------------
if not exist "%VENDOR%" mkdir "%VENDOR%"
if not exist "%WHEELS%" mkdir "%WHEELS%"

:: ---- Download Python 3.12 embeddable zip ----------------------------
echo.
echo  [1/3] Downloading Python 3.12.9 embeddable runtime...
set PY_URL=https://www.python.org/ftp/python/3.12.9/python-3.12.9-embed-amd64.zip
set PY_DEST=%VENDOR%\python-3.12.9-embed-amd64.zip

if exist "%PY_DEST%" (
    echo  [OK]  Already downloaded -- skipping.
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%PY_URL%' -OutFile '%PY_DEST%' -UseBasicParsing"
    if not exist "%PY_DEST%" (
        echo  [ERR] Failed to download Python embeddable zip.
        pause & exit /b 1
    )
    echo  [OK]  Python embeddable zip downloaded.
)

:: ---- Download get-pip.py --------------------------------------------
echo.
set GETPIP_DEST=%VENDOR%\get-pip.py
if exist "%GETPIP_DEST%" (
    echo  [OK]  get-pip.py already present -- skipping.
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://bootstrap.pypa.io/get-pip.py' -OutFile '%GETPIP_DEST%' -UseBasicParsing"
    if not exist "%GETPIP_DEST%" (
        echo  [ERR] Failed to download get-pip.py.
        pause & exit /b 1
    )
    echo  [OK]  get-pip.py downloaded.
)

:: ---- Download all wheels for Windows x64 Python 3.12 ---------------
echo.
echo  [2/3] Downloading all package wheels for Windows x64 / Python 3.12...
echo        (pyodbc, pandas, openpyxl, flask, flask-cors + all dependencies)
echo        This may take a minute...
echo.

python -m pip download ^
    pyodbc ^
    pandas ^
    openpyxl ^
    flask ^
    flask-cors ^
    --dest "%WHEELS%" ^
    --platform win_amd64 ^
    --python-version 3.12 ^
    --implementation cp ^
    --abi cp312 ^
    --only-binary :all: ^
    --quiet

if %errorlevel% neq 0 (
    echo.
    echo  [!!]  pip download exited with errors.
    echo        Some packages may have been partially downloaded.
    echo        Check the output above and retry if needed.
    echo.
    echo  Tip: if a package has no binary wheel for win_amd64/cp312,
    echo       try without --only-binary to allow source builds,
    echo       but you will then need a C compiler on the target.
    echo.
    pause
    :: Don't exit -- partial downloads are still useful
)

echo.
echo  [OK]  Wheels downloaded to vendor\wheels\
echo.
dir /b "%WHEELS%" | find /c ".whl" > nul 2>&1
for /f %%n in ('dir /b "%WHEELS%\*.whl" 2^>nul ^| find /c ".whl"') do echo        %%n wheel files present.

:: ---- Build the portable zip -----------------------------------------
echo.
echo  [3/3] Building DriftDetector_portable.zip...

set OUT_ZIP=%ROOT%DriftDetector_portable.zip
if exist "%OUT_ZIP%" del /f /q "%OUT_ZIP%"

:: Use PowerShell's Compress-Archive on the whole folder
:: Exclude python\ runtime dir (gets built at bootstrap time on target)
:: Exclude any existing .zip inside vendor (we copy the embed zip in)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "Add-Type -Assembly 'System.IO.Compression.FileSystem'; ^
     $src  = '%ROOT%'.TrimEnd('\'); ^
     $dest = '%OUT_ZIP%'; ^
     $exclude = @('.git','__pycache__','*.pyc','logs','reports','data'); ^
     [IO.Compression.ZipFile]::CreateFromDirectory($src, $dest)"

:: Fallback to simple Compress-Archive if above fails
if not exist "%OUT_ZIP%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '%ROOT%*' -DestinationPath '%OUT_ZIP%' -Force"
)

if exist "%OUT_ZIP%" (
    for %%s in ("%OUT_ZIP%") do echo  [OK]  Output: %OUT_ZIP%  (%%~zs bytes)
) else (
    echo  [ERR] Failed to create zip. Zip the DriftDetector folder manually.
)

echo.
echo  ================================================================
echo   Build complete.
echo  ================================================================
echo.
echo   vendor\python-3.12.9-embed-amd64.zip  -- Python runtime
echo   vendor\get-pip.py                     -- pip bootstrapper
echo   vendor\wheels\*.whl                   -- all packages
echo.
echo   Deploy: copy DriftDetector_portable.zip to the target server,
echo   unzip it, then run bootstrap.bat -- no internet needed.
echo.
pause
